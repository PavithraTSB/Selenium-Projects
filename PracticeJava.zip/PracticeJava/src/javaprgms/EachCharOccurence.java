package javaprgms;

import java.util.LinkedHashMap;
import java.util.Map;

public class EachCharOccurence {

	public static void main(String[] args) {
		
		String text="Pavithra";
		char[] ch =text.toCharArray();
		
		Map<Character,Integer>eachChar=new LinkedHashMap<>();
		for (char c : ch) {
			
			if(eachChar.containsKey(c))
			{
				Integer Value=eachChar.get(c);
				eachChar.put(c, Value+1);
			}
			else
			{
			eachChar.put(c, 1);
			}
			
		}
		System.out.println(eachChar);
	}

}
