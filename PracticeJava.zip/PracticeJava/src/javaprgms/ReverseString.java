package javaprgms;

public class ReverseString {

	public static void main(String[] args) {
		
		String name="Pavithra";
		String b="";
		for(int i=0;i<name.length();i++)
		{
			b=name.charAt(i)+b;
		}

		System.out.println(b);
	}

}
