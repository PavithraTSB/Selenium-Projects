package javaprgms;

public class ReverseNum {

	public static void main(String[] args) {
		
		int num=14617;
		int b=0;
		
		while(num!=0)
		{
			b=b*10;
			b=b+num%10;
			num=num/10;
		}
		System.out.println(b);
	}

}
