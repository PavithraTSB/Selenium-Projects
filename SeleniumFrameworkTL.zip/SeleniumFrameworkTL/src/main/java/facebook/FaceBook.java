package facebook;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class FaceBook {

	public static void main(String[] args) {
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		//Browser launch
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		driver.findElementById("email").sendKeys("balamurali.tks@gmail.com");
		driver.findElementByXPath("//input[@type='submit']/preceding::input[@name='pass']").sendKeys("bhuvaneswari");
		driver.findElementByXPath("//input[@type='submit']").click();
		

		
		

	}

}
