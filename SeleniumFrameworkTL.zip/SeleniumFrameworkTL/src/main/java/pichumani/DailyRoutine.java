package pichumani;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class DailyRoutine {
  
  @BeforeMethod
  public void intoOfc() {
	  System.out.println("Pichu entering to ofc");
 }

  @AfterSuite
  public void goingToBed() {
	  System.out.println("Pichu going to bed");
  }

  @BeforeClass
  public void wearFormals() {
	  System.out.println("Pichu Wearing Formals");
  }

  @AfterTest
  public void againBrush() {
	  System.out.println("Pichu brushing again");
  }

  @BeforeTest
  public void brush() {
	  System.out.println("Pichu brushing");
  }
  
  @Test
  public void takeBreak()
  {
	 System.out.println("Pichu going for a tea break"); 
  }
  
  @Test
  public void inAfterBreak()
  {
	  System.out.println("Pichu going to ofc again after break");
  }

  @AfterClass
  public void wearCasuals() {
	  System.out.println("Pichu wearing casuals");
  }

  @BeforeSuite
  public void wakeup() {
	   System.out.println("Pichu Wakeup");
	  
  }

  @AfterMethod
  public void OutToOfc() {
	  
	 System.out.println("Pichu going to home");
  }
  
   

}
