package wdmethods;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class SeMethods implements WdMethods {
	public RemoteWebDriver driver;
	int i =1;
	@Override
	public void startApp(String browser, String url) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.get(url); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("The browser "+browser+" launched successfully"); 
		takeSnap();
	}

	@Override
	public WebElement locateElement(String locator, String locValue) {
		try {
			switch (locator.toLowerCase()) {
			case "id": return driver.findElementById(locValue);
			case "name": return driver.findElementByName(locValue);	
			case "xpath": return driver.findElementByXPath(locValue);
			case "class": return driver.findElementByClassName(locValue);
			case "linktext":return driver.findElementByLinkText(locValue);
			case "cssselector":return driver.findElementByCssSelector(locValue);
			
			}
		} catch (NoSuchElementException e) {
			System.out.println("The element is not found");
		} catch (WebDriverException e) {
			System.out.println("Unknown Exception occured");
		} 
		return null;
	}
    @Override
	public WebElement locateElement(String locValue) {
		try {
			return driver.findElementById(locValue);
		} catch (NoSuchElementException e) {
			System.out.println("The Element is not found");
		}catch (WebDriverException e) {
			System.out.println("Unknown Exception Occured");
		}
		return null;
	}

	@Override
	public void type(WebElement ele,String data) {
		try {
			ele.sendKeys(data);
			System.out.println("The data  enter successfully");
		} catch (WebDriverException e) {
			System.out.println("The data "+data+" not enter successfully");
		 } finally {
			takeSnap();
		}
	}
	
	@Override
	public void clear(WebElement ele)
	{
		ele.clear();
	}

	@Override
	public void click(WebElement ele) {
		try {
			ele.click();
			System.out.println("The element "+ele+" clicked"); 
			takeSnap();
		} catch (NoSuchElementException e) {
			System.out.println("The Element is not found or Clickable");
		}catch (WebDriverException e) {
			System.out.println("Unknown Exception found");
		}
	
	}
	
	public void clickWithOutSnap(WebElement ele) {
		ele.click();
		System.out.println("The element "+ele+" clicked"); 
	}

	@Override
	public String getText(WebElement ele) {
		String text=null;
        text = ele.getText();
		return text;
	}

	@Override
	public void selectDropDownUsingText(WebElement ele, String value) {
		
		try {
			Select dd=new Select(ele);
			dd.selectByVisibleText(value);
			takeSnap();
		} catch (NoSuchElementException e) {
			System.out.println("The Element is not found");
		}

	}

	@Override
	public void selectDropDownUsingIndex(WebElement ele, int index) {
		

	}

	@Override
	public boolean verifyTitle(String expectedTitle) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void verifyExactText(WebElement ele, String expectedText) {
		// TODO Auto-generated method stub

	}

	@Override
	public void verifyPartialText(WebElement ele, String expectedText) {
		// TODO Auto-generated method stub

	}

	@Override
	public void verifyExactAttribute(WebElement ele, String attribute, String value) {
		// TODO Auto-generated method stub

	}

	@Override
	public void verifyPartialAttribute(WebElement ele, String attribute, String value) {
		// TODO Auto-generated method stub

	}

	@Override
	public void verifySelected(WebElement ele) {
		// TODO Auto-generated method stub

	}

	@Override
	public void verifyDisplayed(WebElement ele) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void switchToWindow(int index) {
		
		try {
			Set<String>w1=driver.getWindowHandles();
			List<String>w2=new ArrayList<>();//No get() method in set so using list
			w2.addAll(w1);
			driver.switchTo().window(w2.get(index));
			driver.manage().window().maximize();
		} catch (NoSuchWindowException e) {
			System.out.println("The Window is not present");
		}
		

	}

	@Override
	public void switchToFrame(WebElement ele) {
	
		driver.switchTo().frame(ele);

	}

	@Override
	public void acceptAlert() {
		
		try {
			driver.switchTo().alert().accept();
		} catch (NoAlertPresentException e) {
			System.out.println("There is no alert present");
		}catch (UnhandledAlertException e) {
			System.out.println("There is alert present but you did not handle it");
		}

	}

	@Override
	public void dismissAlert() {
		try {
			driver.switchTo().alert().dismiss();
		} catch (NoAlertPresentException e) {
			System.out.println("There is no alert present");
		}catch (UnhandledAlertException e) {
			System.out.println("There is alert present but you did not handle it");
		}
	}

	@Override
	public String getAlertText() {
		try {
			driver.switchTo().alert().getText();
		} catch (NoAlertPresentException e) {
			System.out.println("There is no alert present");
		}catch (UnhandledAlertException e) {
			System.out.println("There is alert present but you did not handle it");
		}
		return null;
	}

	@Override
	public void takeSnap() {
		File src = driver.getScreenshotAs(OutputType.FILE);
		File dec = new File("./snap/img"+i+".png");
		try {
			FileUtils.copyFile(src, dec);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		i++;
	}

	@Override
	public void closeBrowser() {
		driver.close();
		System.out.println("Close the browser");

	}

	@Override
	public void closeAllBrowsers() {
		driver.quit();
		System.out.println("Close all the browsers");
	}

	

}
