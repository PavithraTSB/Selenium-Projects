package wdmethods;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;

public class ProjectMethods extends SeMethods{
	@Test
	
	
	public void login() {
		
		
		
		
		WebElement eleUsername = locateElement("id", "username");
		type(eleUsername,"DemoSalesManager");
		
		WebElement elePassword = locateElement("id", "password");
		type(elePassword,"crmfsa");
		
		WebElement eleLogin = locateElement("class", "decorativeSubmit");
		click(eleLogin); 
	}
	

}
