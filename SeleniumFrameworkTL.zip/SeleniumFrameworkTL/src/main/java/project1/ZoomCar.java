package project1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZoomCar {

	public static void main(String[] args) {
	
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		//Browser launch
		driver.get("https://www.zoomcar.com/chennai");
		driver.manage().window().maximize();
		
		driver.findElementByClassName("search").click();
		
		driver.findElementByXPath("//div[@class='heading']/following::div[@class='items']").click();
		driver.findElementByXPath("//button[@class='proceed']").click();
		
		driver.findElementByXPath("(//div[@class='text'])[2]").click();
		
		driver.findElementByClassName("proceed").click();
	    driver.findElementByClassName("proceed").click();
	    
	    List<WebElement>ls=driver.findElementsByXPath("//div[@class='price']");
	    System.out.println(ls);
	    
	    int size=ls.size();
	    System.out.println(size);
	    
	    ArrayList<WebElement>list=new ArrayList<>();
	    for (WebElement ele : list) {
	    	
	    	
	    	
	    	
			
	    
		}
	    
	    
	    
	    
	    
		
	}

}
