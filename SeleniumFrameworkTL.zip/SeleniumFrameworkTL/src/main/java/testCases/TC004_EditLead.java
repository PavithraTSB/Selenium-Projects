package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TC004_EditLead extends TC003_MergeLeads {
	
	@Test(groups="test.reg")
	public void editlead()
	
	{
		WebElement edit=locateElement("linktext","Edit");
		click(edit);
		
		
		WebElement fname=locateElement("id","updateLeadForm_firstName");
		clear(fname);
		type(fname,"Pavithra");
		
		WebElement lname=locateElement("id","updateLeadForm_lastName");
		clear(lname);
		type(lname,"Vishnu");
		
		WebElement submit=locateElement("name","submitButton");
		click(submit);
	}

}
