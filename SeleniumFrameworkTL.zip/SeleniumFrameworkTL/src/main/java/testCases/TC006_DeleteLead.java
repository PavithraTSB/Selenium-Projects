package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TC006_DeleteLead extends TC005_DuplicateLead{
	
	@Test(groups="test.smoke")
	public void deletelead()
	{
		WebElement delete=locateElement("linktext","Delete");
		click(delete);
		
		
	}

}
