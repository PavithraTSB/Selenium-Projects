package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wdmethods.ProjectMethods;
import wdmethods.SeMethods;

@Test   
public class TC001_Login extends ProjectMethods{
   public void tc1()
	
	{
		login();
	}

	}









