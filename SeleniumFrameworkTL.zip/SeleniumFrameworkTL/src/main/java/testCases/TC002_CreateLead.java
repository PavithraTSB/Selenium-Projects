package testCases;

import org.junit.BeforeClass;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import wdmethods.ProjectMethods;
import wdmethods.SeMethods;




public class TC002_CreateLead extends ProjectMethods{

	
	
	@Test
	public void CreateLead() {
		 	
		    login();
		
		    WebElement crmsfalink=locateElement("linktext","CRM/SFA");
			click(crmsfalink);
			
			WebElement createlead=locateElement("linktext","Create Lead");
			click(createlead);
			
			WebElement compname=locateElement("id","createLeadForm_companyName");
			type(compname,"IBM");
			
			WebElement fname=locateElement("id","createLeadForm_firstName");
			type(fname,"Pavi");
			
		    WebElement lname=locateElement("id","createLeadForm_lastName");
		    type(lname,"Vishnu");
		    
		    WebElement submit=locateElement("name","submitButton");
		    click(submit);
		    
		    WebElement leads=locateElement("linktext","Leads");
		    click(leads);
		 
		    
		    
		}
	
	@DataProvider(name="fetchData")
	public String[][] getdata()
	{
	String [][] data=new String[2][3];
	
       data [0][0]="IBM";
       data[0][1]="Pavi";
       data[0][2]="Vish";
       
       
       data [0][0]="CTS";
       data[0][1]="Vishnu";
       data[0][2]="Pavi";
	   return data;
       
	}
	
	
	
	
}
