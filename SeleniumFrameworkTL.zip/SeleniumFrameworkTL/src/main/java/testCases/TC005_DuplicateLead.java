package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TC005_DuplicateLead extends TC004_EditLead{

	@Test(groups="test.sanity")
	public void duplicatelead()
	{
		
    	WebElement duplead=locateElement("linktext","Duplicate Lead");
    	click(duplead);
    	
    	WebElement compname=locateElement("id","createLeadForm_companyName");
    	clear(compname);
    	type(compname,"Accenture");
    	
    	WebElement fname=locateElement("id","createLeadForm_firstName");
    	clear(fname);
    	type(fname,"Vrishank");
    	
    	WebElement lname=locateElement("id","createLeadForm_lastName");
    	clear(lname);
    	type(lname,"Prasanna");
    	
    	WebElement submit=locateElement("name","submitButton");
    	click(submit);
	}
	
	
}
