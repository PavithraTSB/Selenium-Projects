package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wdmethods.SeMethods;

@Test(groups="test.smoke")
public class TC003_MergeLeads extends TC002_CreateLead{

	  
	   public void mergelead() throws InterruptedException 
	   {
		  
		WebElement mergeleads=locateElement("linktext","Merge Leads");
		click(mergeleads);
		
		//Click From Lead
		WebElement fromlead=locateElement("xpath","(//a[@class='buttonDangerous']/preceding::img[@alt='Lookup'])[1]");
		click(fromlead);
		
		//Switching to new window and sending keys to fname
		switchToWindow(1);
		WebElement leadfname=locateElement("name","firstName");
		type(leadfname,"Pavithra");
		
		//Click on find leads button
		WebElement findleads=locateElement("class","x-panel-btn-td");
		click(findleads);
		
		//Clicking on 1st record for from lead
		Thread.sleep(3000);
		WebElement record=locateElement("class","linktext");
		click(record);
		
		//Switch back to Primary window and clicking to lead
		switchToWindow(0);
		WebElement tolead=locateElement("xpath","(//a[@class='buttonDangerous']/preceding::img[@alt='Lookup'])[2]");
		click(tolead);
		
		//Switching to new window and sending keys to fname
		switchToWindow(1);
		WebElement compname1=locateElement("name","companyName");
		type(compname1,"IBM");
		
		//Click on find leads button
		WebElement findleads1=locateElement("class","x-panel-btn-td");
		click(findleads1);
		
		//Clicking on 1st record for from lead
		Thread.sleep(3000);
		WebElement records=locateElement("class","linktext");
		click(records);
		
		//Switch back to Primary window and clicking to lead
		switchToWindow(0);
		
		//Merge
		WebElement merge=locateElement("class","buttonDangerous");
		click(merge);
		
		
		//Alert
		acceptAlert();
	
		
		
		}

	
}
