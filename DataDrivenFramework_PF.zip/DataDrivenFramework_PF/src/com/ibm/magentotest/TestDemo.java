package com.ibm.magentotest;



import org.testng.Assert;
import org.testng.annotations.*;

public class TestDemo {
	
	/*@BeforeTest
	public void bTest()
	{
		System.out.println("Before Test");
	}
	
	@AfterTest
	public void aTest()
	{
		System.out.println("After Test");
	}
	
	
	@BeforeSuite
	public void bSuite()
	{
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	public void aSuite()
	{
		System.out.println("After Suite");
	}
	
	
	@BeforeMethod
	public void bMethod()
	{
		System.out.println("bMethod");
	}
	
	@AfterMethod
	public void aMethod()
	{
		System.out.println("aMethod");
	}*/
	
	@Test
	public void test1()
	{
		System.out.println("Test 1");
	}
	
	@Test
	public void test2()
	{
		System.out.println("Test 2");
	}

	@Test
	public void test3()
	{
		System.out.println("Test 3");
	}
	@Test
	public void baseTest1()
	{
		System.out.println("baseTest1");
	}
	
	@Test
	public void baseTest2()
	{
		System.out.println("baseTest2dddd");
		Assert.fail();
		
	}

	@Test
	public void baseTest3()
	{
		System.out.println("baseTest3");
	}
}
