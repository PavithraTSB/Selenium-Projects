package com.ibm.actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ActionKeywords {
	WebDriver driver;
	
	public ActionKeywords(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void clickByXpathLocators(String xpath)
	{
		driver.findElement(By.xpath(xpath)).click();
	}

}
