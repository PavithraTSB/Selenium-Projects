	package com.ibm.pages;
	
	import java.util.List;
	
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.How;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.WebDriverWait;
	
	public class UserPortalLoginPage {
	
		WebDriverWait wait;
		WebDriver driver;
		@FindBy(how=How.XPATH,using="//span[@class='input-group-addon']")WebElement searchIcon;
		@FindBy(how=How.XPATH,using="(//span[@class='click-categories flaticon-bars'])[2]")WebElement categoryList;
		@FindBy(how=How.XPATH,using="//input[@type='text']")WebElement searchProducts;
		@FindBy(how=How.XPATH,using="//span[text()='Bislery Water']")WebElement searchResult;
		@FindBy(how=How.XPATH,using="//*[@id='mm-0']/div[5]/div/div[2]/div/div/div[2]/div/p[1]/span") WebElement pricetext;
		@FindBy(how=How.XPATH,using="//a[@class='register']")WebElement signup;
		@FindBy(how=How.XPATH,using="//input[@id='name']")WebElement fullname;

		
		public String resulttext;
		public UserPortalLoginPage(WebDriver driver,WebDriverWait wait) {
			PageFactory.initElements(driver, this);
			this.driver=driver;
			this.wait=wait; 
		}
		public void clickSearchIcon()
		{
			searchIcon.click();
		}

		public void shopByCategory() throws InterruptedException
		{
			categoryList.click();
			
		}
		public void searchproduct(String product)
		{
			searchProducts.sendKeys(product);
			
		}
		public void clickOnSearchResults()
		{
			searchResult.click(); 
		}
		
		public float expected_value;
		
		public void price_value()
		{
		String pc=	pricetext.getText().replace("₹", "");
		
		float value=Float.parseFloat(pc);
		
		expected_value=Math.round(value);
		System.out.println("expected_value :" + expected_value);
		
		}
		public void clickSignup()
		{
			signup.click();
		}
		
		
		public void searchresult()
		{
			
			System.out.println("search start");
			List<WebElement> result= driver.findElements(By.xpath("//*[@id='searchproducts-div']"));
			
			for(WebElement resultget :result )
			{
				resulttext=resultget.getText();
				
				System.out.println("Results found in User Page \n"+resulttext);
			}
		}
		
	}
