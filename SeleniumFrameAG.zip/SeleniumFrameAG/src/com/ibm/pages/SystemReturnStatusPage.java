package com.ibm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SystemReturnStatusPage {
	
	@FindBy(how=How.XPATH,using="//table[@id='dataTableExample2']/tbody/tr[2]/td[3]")WebElement table;
	@FindBy(how=How.XPATH,using="(//button[@class='btn dropdown-toggle btn-primary'])[2]")WebElement action;
	@FindBy(how=How.XPATH,using="(//a[@title='Edit'])[2]")WebElement edit;
	@FindBy(how=How.XPATH,using="//input[@name='name']")WebElement editreturnStatus;
	@FindBy(how=How.XPATH,using="//button[@class='btn btn-primary']")WebElement save;
	
	By validation =By.xpath("//input[@name='name']");
	WebDriver driver;
	WebDriverWait wait;
	
	public SystemReturnStatusPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clicktable()
	{
		table.click();
	}
	public void clickActionButton() {
		action.click();
	}
	public void clickEdit()
	{
		edit.click();
	}
	public void clearEditReturnStatus()
	{
		editreturnStatus.clear();
	}
    public void clickSave()
    {
    	save.click();
    }
     
    	
    	public String getPageSrctoVerifypage()
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(validation));
			
			return driver.getPageSource();
		}
   
   
}
