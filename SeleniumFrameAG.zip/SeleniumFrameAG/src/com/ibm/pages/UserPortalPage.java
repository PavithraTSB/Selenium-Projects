package com.ibm.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserPortalPage {
	
	WebDriverWait wait;
	WebDriver driver;
	
	@FindBy(how=How.XPATH,using="//a[@onclick='myAccount()']")WebElement myAcc;
	@FindBy(how=How.XPATH,using="//a[text()='My Address']")WebElement myAddress;
	@FindBy(how=How.XPATH,using="//button[@class='button button-check-out']")WebElement update;
	@FindBy(how=How.XPATH,using="//input[@id='email']")WebElement emailAddress;
	@FindBy(how=How.ID,using="address")WebElement address;
	@FindBy(how=How.ID,using="city")WebElement city;
	@FindBy(how=How.ID,using="pincode")WebElement pincode;
	@FindBy(how=How.XPATH,using="(//*[@class='alert alert-success alert-dismissible'])[2]")WebElement successMsg;
	
	
	public String msg;
	public String attributeValue;
	
	public UserPortalPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait; 
	}
	public void clickMyAccount()
	{
		myAcc.click();
	}
	public void clickMyAddress()
	{
		myAddress.click();
	}
	public void clickUpdate()
	{
		update.click();
	}
	public String getValidationForEmailAddress()
	{
		String tooltipmessage= "return document.getElementsByName('email')[0].validationMessage";
		return ((JavascriptExecutor) driver).executeScript(tooltipmessage).toString();
	}
	public void sendEmailAddress(String data)
	{
		emailAddress.sendKeys(data);
	}
	public void sendAddress(String data)
	{
		address.sendKeys(data);
	}
	public void sendCity(String data)
	{
		city.sendKeys(data);
	}
	public void sendPincode(String data)
	{
		pincode.sendKeys(data);
	}
    public void validateSuccessMsg()
    {
    	msg = successMsg.getText();
    	System.out.println(msg);
    	
    }
    public void getAttrName()
    {
    	 attributeValue = emailAddress.getAttribute("value");
    	 System.out.println("Attribute values is :"+attributeValue);
    }
   
}
