package com.ibm.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShippingPincodePage {
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[20]")WebElement shipping;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[23]")WebElement shippingPincode;
	@FindBy(how=How.XPATH,using="//a[@class='btn btn-primary']")WebElement addNewShipping;
	@FindBy(how=How.XPATH,using="//*[text()='Shipping Pincode']")WebElement headerShippingPincode;
	@FindBy(how=How.XPATH,using="//button[@class='btn btn-primary']")WebElement save;
	@FindBy(how=How.XPATH,using="//input[@name='pincode']")WebElement pincode;
	@FindBy(how=How.XPATH,using="//*[@class='alert alert-success alert-dismissible']")WebElement successMsg;
	@FindBy(how=How.XPATH,using="//input[@class='form-control input-sm']")WebElement search;
	@FindBy(how=How.XPATH,using="//table[@id='dataTableExample2']/tbody/tr/td[2]")WebElement table;
	
	WebDriverWait wait;
	WebDriver driver;
	JavascriptExecutor js;
	public String headerShipping;
	public String text;
	public String textFromTable;
	
	public ShippingPincodePage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickShipping()
	{
		shipping.click();
	}
	public void clickShippingPincode()
	{
	    shippingPincode.click();
	}
	public void clickAddNewShipping()
	{
		addNewShipping.click();
	}
	public void getHeaderShippingPincode()
	{
		headerShipping = headerShippingPincode.getText();
		System.out.println("Header is :"+headerShipping);
	}
	public void clickonSaveShippingPincode()
	{
		save.click();
	}
	public String tooltipValidationMsg()
	{
		String tooltipmessage= "return document.getElementsByName('pincode')[0].validationMessage";
		return ((JavascriptExecutor) driver).executeScript(tooltipmessage).toString();
	    
	}
	public void sendkeysPincode(String data)
	{
		pincode.sendKeys(data);
	}
    public void validatingSuccessMsg()
    {
    	text = successMsg.getText();
    	System.out.println("Success Msg is :" +text);
     }
    public void sendValuetoSearch(String data)
    {
    	search.sendKeys(data);
    }
    public void getTextFromTable()
    {
    	textFromTable = table.getText();
    	System.out.println("text =" +textFromTable);
    }
	}


