package com.ibm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserPortalSignUpPage {

	WebDriverWait wait;
	WebDriver driver;
	
	@FindBy(how=How.XPATH,using="//input[@id='name']")WebElement fullname;
	@FindBy(how=How.XPATH,using="//input[@id='pnum']")WebElement PhNum;
	@FindBy(how=How.XPATH,using="//input[@id='password']")WebElement pwd;
	@FindBy(how=How.XPATH,using="//input[@id='cpassword']")WebElement cpwd;
	@FindBy(how=How.XPATH,using="//input[@id='tccheckbox']")WebElement tandc;
	@FindBy(how=How.XPATH,using="//button[@id='mem_signup']")WebElement signupButton;
	
	public UserPortalSignUpPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait; 
	}
	public void sendDataFullName(String data)
	{
		fullname.sendKeys(data);
	}
	public void sendDataPhNum(String data)
	{
		PhNum.sendKeys(data);
	}
	public void sendDataPassword(String data)
	{
		pwd.sendKeys(data);
	}
	public void sendDataConfirmPassword(String data)
	{
		cpwd.sendKeys(data);
	}
	public void clickTermsandConditions()
	{
		tandc.click();
	}
	public void clickSignupButton()
	{
		signupButton.click();
	}
	public void clickAlert()
	{
		driver.switchTo().alert().accept();
	}
}
