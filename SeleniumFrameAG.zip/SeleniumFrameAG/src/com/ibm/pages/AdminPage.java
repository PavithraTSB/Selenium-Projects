package com.ibm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;




public class AdminPage {
	@FindBy(how=How.NAME,using="email")WebElement emailEle;
	@FindBy(how=How.NAME,using="pword")WebElement passEle;
	@FindBy(how=How.XPATH,using="//button[@class='btn btn-labeled btn-info m-b-5']")WebElement loginEle;
	WebDriverWait wait;
	WebDriver driver;
	
	public AdminPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public AdminPage enterEmailAddress(String uname)
	{
		emailEle.sendKeys(uname);
		return this;
	}
	
	public AdminPage enterPassword(String pwd)
	{
		passEle.sendKeys(pwd);
		return this;
	}
	
	public void clickOnLogin()
	{
		loginEle.click();
	    
	}
	
}
