	package com.ibm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SystemPage {
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[17]")WebElement system;
	
	
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[26]")WebElement returns;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[27]")WebElement returnsStatuses;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[25]")WebElement weightClass;
	
	WebDriverWait wait;
	WebDriver driver;
	
	public SystemPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickSystem()
	{
		system.click();
	}
	public void clickWeightClass()
	{
		weightClass.click();
	}
    public void clickReturns()
    {
    	returns.click();
    }
    public void clickReturnStatuses()
    {
    	returnsStatuses.click();
    }
    
    
}



