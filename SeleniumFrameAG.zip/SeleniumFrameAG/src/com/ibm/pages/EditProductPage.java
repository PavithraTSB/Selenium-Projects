package com.ibm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EditProductPage {
 @FindBy(how=How.ID,using="pro_name")WebElement pName;
 @FindBy(how=How.XPATH,using="//button[@class='btn btn-primary']")WebElement save;
 @FindBy(how=How.LINK_TEXT,using="Data")WebElement data;
 @FindBy(how=How.XPATH,using="//*[@id='status']")WebElement status;
 @FindBy(how=How.XPATH,using="//button[@class='btn btn-primary']/i")WebElement dataSave;
	WebDriverWait wait;
	WebDriver driver;
	
    By validation=By.xpath("//input[@id='pro_name']");
	
	public EditProductPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
		

	}
	public void removeProductName()
	{
		pName.clear(); 
	}
	public void clickSave()
	{
		save.click();
		
	}
	public void clickData()
	{
		data.click();
	}
	public void selectStatus()
	{
		Select se=new Select(status);
		se.selectByVisibleText("Disabled");
	}
	public void clickDataSave()
	{
		dataSave.click();
	}
	public String getPagesourceForNegativeValidation()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(validation));
		
		return driver.getPageSource();
	
		
	}
	
	
}
