package com.ibm.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CategoriesPage {

	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[5]")WebElement categories;
	
	WebDriverWait wait;
	WebDriver driver;
	
	public CategoriesPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void categories()
	{
		categories.click();
	}

}
