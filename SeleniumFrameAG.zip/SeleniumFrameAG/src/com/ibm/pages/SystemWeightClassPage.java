package com.ibm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SystemWeightClassPage {

@FindBy(how=How.XPATH,using="//table[@id='dataTableExample2']/tbody/tr/td[5]")WebElement table;
@FindBy(how=How.XPATH,using="//button[@class='btn dropdown-toggle btn-primary']")WebElement action;
@FindBy(how=How.XPATH,using="//a[@title='Edit']")WebElement edit;
@FindBy(how=How.XPATH,using="(//input[@class='form-control'])[2]")WebElement weightUnit;
@FindBy(how=How.XPATH,using="//button[@title='Save']")WebElement save;
@FindBy(how=How.XPATH,using="//*[@id=\"page-wrapper\"]/div/form/div[2]/div/div/div[1]/div/h4")WebElement verifyPage;


By validation =By.xpath("//*[@id=\"page-wrapper\"]/div/form/div[2]/div/div/div[1]/div/h4");
WebDriver driver;
WebDriverWait wait;
JavascriptExecutor js;
	
	public SystemWeightClassPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickTable()
	{
		table.click();
	}
	public void clickActionButton()
	{
		action.click();
	}
	public void clickEdit()
	{
		edit.click();
	}
	public void clearWeightUnit()
	{
		weightUnit.clear();
	}
    public void clickSave()
    {
    	save.click();
    }
    public String getPageSrcttoVerifypage()
	{
		
//		System.out.println("Verified it is on the same page :"+text);
    	wait.until(ExpectedConditions.presenceOfElementLocated(validation));
		
		return verifyPage.getText();
	}
    public String getValidationForNoWeightUnit()

    {

    String tooltipmessage= "return document.getElementsByName('unit')[0].validationMessage";
	return ((JavascriptExecutor) driver).executeScript(tooltipmessage).toString();
    	
    } 

}
