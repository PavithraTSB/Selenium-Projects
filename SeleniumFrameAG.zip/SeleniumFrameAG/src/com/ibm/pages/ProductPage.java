package com.ibm.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sun.glass.events.KeyEvent;

public class ProductPage {

	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[2]")WebElement catalog;
	@FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[6]")WebElement products;
	@FindBy(how=How.XPATH,using="//a[@class='btn btn-primary']")WebElement add;
	@FindBy(how=How.ID,using="pro_name")WebElement productName;
	@FindBy(how=How.ID,using="meta_title")WebElement metatitle;
	@FindBy(how=How.XPATH,using="//button[@class='btn btn-primary']")WebElement save;
	@FindBy(how=How.XPATH,using="//table[@id='dataTableExample2']/tbody/tr/td[9]")WebElement table;
    @FindBy(how=How.LINK_TEXT,using="Delete")WebElement delete;
	@FindBy(how=How.XPATH,using="//*[@class='sweet-alert showSweetAlert visible']")WebElement sweetAlert;
	@FindBy(how=How.XPATH,using="//button[@class='confirm']")WebElement deleteConfirmation;
	@FindBy(how=How.LINK_TEXT,using="Edit")WebElement edit;
	@FindBy(how=How.XPATH,using="//input[@class='form-control input-sm']")WebElement search;
	@FindBy(how=How.XPATH,using="//*[@id='dataTableExample2']/tbody/tr/td[5]") WebElement price;
	@FindBy(how=How.LINK_TEXT,using="Data")WebElement data;
	@FindBy(how=How.ID,using="model")WebElement model;
	@FindBy(how=How.ID,using="gst")WebElement gst;
	@FindBy(how=How.ID,using="price")WebElement dataPrice;
	@FindBy(how=How.ID,using="special_dis")WebElement splDis;
	@FindBy(how=How.ID,using="price_after_special_dis")WebElement priceAfterSplDis;
	@FindBy(how=How.LINK_TEXT,using="Link")WebElement link;
	@FindBy(how=How.ID,using="tabs")WebElement tabsDropdown;
	@FindBy(how=How.ID,using="categories")WebElement categories;
	@FindBy(how=How.LINK_TEXT,using="Image")WebElement image;
	@FindBy(how=How.XPATH,using="//span[@class='btn btn-info btn-file']")WebElement productImage;
	@FindBy(how=How.XPATH,using="//*[@class='alert alert-danger alert-dismissible']")WebElement successMsg;
	
	WebDriverWait wait;
	WebDriver driver;
	
	public String prodNames;
	public String sucessfullmsg;
	public ProductPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickCatalog()
	{
		catalog.click();
	}
	public void clickProducts()
	{
		products.click();
	}
	public void clickAdd()
	{
		add.click();
	}
	public void sendValuesProductName(String data)
	{
		productName.sendKeys(data);
	}
	public void sendValuesMetaTitle(String data)
	{
		metatitle.sendKeys(data);
	}
	public void clickSave()
	{
		save.click();
	}
	public void actionTable()
	{
		table.click();
	}
	public void clickDelete()
	{
		delete.click();
	}
	public void clickSweetAlert()
	{
		sweetAlert.click();
	}
	public void confirmationDelete()
	{
		deleteConfirmation.click();
	}
	public void clickEdit()
	{
		edit.click(); 
	}
	public void sendkeysSearch(String data)
	{
		search.sendKeys(data);
	}
	public void clickData()
	{
		data.click();
	}
	public void sendValuesModel(String data)
	{
		model.sendKeys(data);
	}
	public void sendGstValue(String data)
	{
		gst.sendKeys(data);
	}
	public void sendDataPriceValue(String data)
	{
		dataPrice.sendKeys(data);
	}
	public void sendSplDiscountValue(String data)
	{
		splDis.sendKeys(data);
	}
	public void sendPriceAfterSplDis(String data)
	{
		priceAfterSplDis.sendKeys(data);
	}
	public void clickLink()
	{
		link.click();
	}
	public void selectTabsDropdown()
	{
		Select se=new Select(tabsDropdown);
		se.selectByVisibleText("Tab_SA");
	}
	public void selectCategories()
	{
		Select sel=new Select(categories);
		sel.selectByVisibleText("Fruits");
	}
	public void clickImage()
	{
		image.click();
	}
	public void sendProductImage() throws InterruptedException
	{
		productImage.click();
		Thread.sleep(3000);
		WebElement frame =driver.switchTo().activeElement();
		frame.sendKeys("C:\\Users\\PavithraTSB\\Desktop\\Assignments\\image.png");
	}
	public void verifyingSuccessMsg()
	{
		sucessfullmsg = successMsg.getText();
		System.out.println(sucessfullmsg);
	}
	public void IterateTableRow()
	{
	 List<WebElement> row = driver.findElements(By.xpath("//table[@id='dataTableExample2']/tbody/tr"));
	 int size = row.size();
	 
	 for(int i=1;i<=size;i++)
	 {
		 WebElement iterateRow = driver.findElement(By.xpath("//table[@id='dataTableExample2']/tbody/tr["+i+"]/td[2]"));
		 prodNames = iterateRow.getText();
		 System.out.println(prodNames);
    }
	}
	
	public float roundOff;
	public void pricevalue()
	{
		String pv=price.getText().replace(",", "");
		String rline=pv.substring(0,pv.indexOf("\n"));
		System.out.println("Actual price : " + rline);
		
		float actual_value=Float.parseFloat(rline);
	
		System.out.println(actual_value);
		
		float percentage = actual_value * 5/100;
	    
		float result = actual_value - percentage;
	  
		
		System.out.println("5 % reduced value:" + result);
		roundOff=Math.round(result);
		System.out.println(roundOff);
		
	}
	
	public static void robot() throws AWTException
	{
	Robot robot=new Robot();
	robot.setAutoDelay(3000);
	robot.keyPress(KeyEvent.VK_ENTER);
	}
}
