package com.ibm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MarketingPushNotificationPage {
  @FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[13]")WebElement marketing;
  @FindBy(how=How.XPATH,using="(//a[@class='material-ripple'])[16]")WebElement pushNotification;
  @FindBy(how=How.XPATH,using="//a[@class=\"btn btn-primary\"]")WebElement add;
  @FindBy(how=How.NAME,using="name")WebElement notificationName;
  @FindBy(how=How.XPATH,using="//*[@name='message']")WebElement notificationMsg;
  @FindBy(how=How.XPATH,using="//button[@class=\"btn btn-primary\"]")WebElement save;
  
  By validation=By.xpath("//input[@name='name']");
 
	WebDriverWait wait;
	WebDriver driver;
	
	public MarketingPushNotificationPage(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	public void clickMarketing()
	{
		marketing.click();
	}
	public void clickPushNotification()
	{
		pushNotification.click();
	}
	public void clickAddButton()
	{
		add.click();
	}
	public void sendNotificationName(String name)
	{
		notificationName.sendKeys(name);
	}
	public void sendNotificationMsg(String msg)
	{
		notificationMsg.sendKeys(msg);
	}
	public void clickSave()
	{
		save.click();
	}
	public String getPagetitleForNegativeValidation()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(validation));
		
		return driver.getTitle();
	}
	
}



