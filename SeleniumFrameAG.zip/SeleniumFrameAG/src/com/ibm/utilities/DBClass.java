package com.ibm.utilities;

import java.sql.SQLException;

public class DBClass extends DB {
	
	public String query;
	public int count;
	public String pushNotificationQuery;
	public String shippingPincodeQuery;
	public String myAccQuery;
	public String prodNameValidation;
	
	public void TC009() throws SQLException
	{
		query = DBClass.singleDataQuery("SELECT * FROM as_customer WHERE name=\"PavithraTSB\"");
		System.out.println(query);
	}
	public void TC10PushNotificationCount() throws SQLException
	{
	  count = DBClass.countQuery("SELECT COUNT(notification_id) FROM as_pushnotification");
	  System.out.println(count);
	}
	public void TC10PushNotificationRecordValidation() throws SQLException
	{
		pushNotificationQuery=DBClass.singleDataQuery("SELECT MESSAGE from as_pushnotification WHERE name=\"Test_Pavithra\"");
		System.out.println(pushNotificationQuery);
	}
	public void tc011ShippingPincodeRecordValidation() throws SQLException
	{
		shippingPincodeQuery = DBClass.singleDataQuery("SELECT * FROM `as_shipping_pincode` WHERE pincode=\"7638932\"");
		System.out.println(shippingPincodeQuery);
	}
	public void tc012MyAccRecordValidation() throws SQLException
	{
		myAccQuery = DBClass.singleDataQuery("SELECT * FROM `as_customer` WHERE address=\"Porur\"");
		System.out.println(myAccQuery);
	}
	public void tC013ProductNameDeletionValidation() throws SQLException
	{
		prodNameValidation = DBClass.singleDataQuery("SELECT * FROM `as_products");
		System.out.println(prodNameValidation);
	}
}