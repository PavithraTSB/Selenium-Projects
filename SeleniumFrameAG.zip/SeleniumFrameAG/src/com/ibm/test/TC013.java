package com.ibm.test;

import java.awt.AWTException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.ProductPage;
import com.ibm.pages.UserPortalLoginPage;
import com.ibm.utilities.DBClass;
import com.ibm.utilities.PropertiesFileHandler;

public class TC013 {
	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "ProductDeleteValidation")
	public void testCase13() throws IOException, InterruptedException, SQLException
	{
		String url = data.get("url");
		String userName = data.get("uname");
		String password = data.get("pwd");
		String prodname=data.get("prodName");
		String metatitle=data.get("metaTitle");
		String modelname=data.get("modelName");
		String gst=data.get("gstPercent");
		String datapricevalues=data.get("dataPriceValues");
		String splDiscountValue=data.get("specialDiscount");
		String priceAfterSplDis=data.get("priceAfterSplDis");
		String expectedSuccessfullMsg="Success: You have successfully deleted data";
		String userUrl=data.get("userurl");
		
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		
		driver.get(url);
		AdminPage admin = new AdminPage(driver, wait);
		admin.enterEmailAddress(userName);
		admin.enterPassword(password);
		admin.clickOnLogin();
		
		ProductPage pp=new ProductPage(driver, wait);
		pp.clickCatalog();
		pp.clickProducts();
		pp.clickAdd();
		pp.sendValuesProductName(prodname);
		pp.sendValuesMetaTitle(metatitle);
		jse.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		pp.clickData();
		pp.sendValuesModel(modelname);
		pp.sendGstValue(gst);
		pp.sendDataPriceValue(datapricevalues);
		pp.sendSplDiscountValue(splDiscountValue);
		pp.sendPriceAfterSplDis(priceAfterSplDis);
		jse.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		pp.clickLink();
		Thread.sleep(3000);
		pp.selectTabsDropdown();
		pp.selectCategories();
		jse.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
		pp.clickImage();
		Thread.sleep(4000);
		pp.sendProductImage();
		pp.clickSave();	
		pp.sendkeysSearch(prodname);
		Thread.sleep(3000);
		pp.actionTable();
		pp.clickDelete();
		pp.clickSweetAlert();
		pp.confirmationDelete();
		Thread.sleep(5000);
		pp.verifyingSuccessMsg();
		//Validating the success msg
		Assert.assertTrue(pp.sucessfullmsg.contains(expectedSuccessfullMsg),"Assertion on required field Message");
		Reporter.log("Verified Successfull Message");
		
		pp.IterateTableRow();
		//Verifying the deleted product under the tab list.
		if(pp.prodNames.contains(prodname))
		{
			Reporter.log("Deleted Product Present in table");
		}
		else
		{
			Reporter.log("Verified Deleted Product not Present in table");
		}
		//Verifying that deleted product is not present on the database
		DBClass dbc=new DBClass();
		dbc.tC013ProductNameDeletionValidation();
		if(dbc.prodNameValidation.contains(prodname))
		{
			Reporter.log("Deleted Product Present in DB");
		}
		else
		{
			Reporter.log("Verified Deleted Product not Present in DB");
		}
		//Verifying the product is not listed on the user page
		driver.get(userUrl);
		UserPortalLoginPage uplp=new UserPortalLoginPage(driver, wait);
		uplp.searchproduct(prodname);
		uplp.clickSearchIcon();
		uplp.searchresult();
		
		if(uplp.resulttext.contains(prodname))
		{
			Reporter.log("Deleted Product Present in UserPage");
		}
		else
		{
			Reporter.log("Verified Deleted Product not Present in UserPage");
		}
		
	}
}
