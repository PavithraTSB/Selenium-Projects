package com.ibm.test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.MarketingPushNotificationPage;
import com.ibm.utilities.DBClass;
import com.ibm.utilities.PropertiesFileHandler;

public class TC010 {

	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "NewPushNotificationValidation")
	public void testCase10() throws IOException, InterruptedException, SQLException {

		            String url = data.get("url");
					String userName = data.get("uname");
					String password = data.get("pwd");
					String name=data.get("pushNotificationName");
					String message=data.get("pushNotificaionMessage");
					driver.get(url);
					
					DBClass dbc=new DBClass();
					System.out.print("Count before adding new record: ");
					dbc.TC10PushNotificationCount();
					
					
					AdminPage admin = new AdminPage(driver, wait);
					admin.enterEmailAddress(userName);
					admin.enterPassword(password);
					admin.clickOnLogin();
					
					MarketingPushNotificationPage mpnp=new MarketingPushNotificationPage(driver, wait);
					mpnp.clickMarketing();
					mpnp.clickPushNotification();
					mpnp.clickAddButton();
					mpnp.sendNotificationName(name);
					mpnp.sendNotificationMsg(message);
					mpnp.clickSave();
					
					System.out.print("Count after adding new record :");
					dbc.TC10PushNotificationCount();
					System.out.print("Retreiving the message to ensure that record has been added :");
					dbc.TC10PushNotificationRecordValidation();
					
					Assert.assertEquals(message,dbc.pushNotificationQuery);
					Reporter.log("New Record is added in DB");
					
							
							
}
}