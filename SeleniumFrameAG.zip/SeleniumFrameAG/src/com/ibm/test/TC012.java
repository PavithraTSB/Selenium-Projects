package com.ibm.test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.UserPortalLoginPage;
import com.ibm.pages.UserPortalPage;
import com.ibm.pages.UserPortalSignUpPage;
import com.ibm.utilities.DBClass;
import com.ibm.utilities.PropertiesFileHandler;

public class TC012 {
	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "ShippingCodeValidation")
	public void testCase12() throws IOException, InterruptedException, SQLException
	{
		String userUrl=data.get("userurl");
		driver.get(userUrl);
		
		String expectedSuccessfullMsg="You have successfully updated address details";
		String fullName=data.get("signUpFullName");
		String PhNumber=data.get("signUpPhNum");
		String pword=data.get("password");
		String cPword=data.get("confirmPassword");
		String emailaddress=data.get("EmailAddress");
		String address=data.get("Address");
		String city=data.get("City");
		String pincodeNum=data.get("pincode");
		String tooltip = data.get("toolTipMessage");
		
		//Click Signup
		UserPortalLoginPage uplp=new UserPortalLoginPage(driver, wait);
		uplp.clickSignup();
		
		//Signupvalues
		UserPortalSignUpPage upsp=new UserPortalSignUpPage(driver, wait);
		upsp.sendDataFullName(fullName);
		upsp.sendDataPhNum(PhNumber);
		upsp.sendDataPassword(pword);
		upsp.sendDataConfirmPassword(cPword);
		upsp.clickTermsandConditions();
		try {
			upsp.clickSignupButton();
			System.out.println("Signup Successfully");
		} catch (Exception e) {
			
			System.out.println("Not Successfull");
		}
		Thread.sleep(3000);
		upsp.clickAlert();
		
		UserPortalPage upp=new UserPortalPage(driver, wait);
		upp.clickMyAccount();
		upp.clickMyAddress();
		upp.clickUpdate();
		
		//validating error message
		String tooltipValidationForEmailAddress = upp.getValidationForEmailAddress();
		System.out.println("Tooltip message is: " +tooltipValidationForEmailAddress);
		Assert.assertTrue(tooltipValidationForEmailAddress.contains(tooltip), "Assertion on required field Message");
		Reporter.log("Verified the tooltip Message");
		
		upp.sendEmailAddress(emailaddress);
		upp.sendAddress(address);
		upp.sendCity(city);
		upp.sendPincode(pincodeNum);
		upp.clickUpdate();
		upp.validateSuccessMsg();
		
		//Validating success msg
		Assert.assertTrue(upp.msg.contains(expectedSuccessfullMsg),"Assertion on required field Message");
		Reporter.log("Verified Successfull Message");
		
		upp.clickMyAccount();
		upp.clickMyAddress();
		upp.getAttrName();
		
		//Validating presence of Address on the Userpage
		Assert.assertEquals(upp.attributeValue,emailaddress);
		Reporter.log("Verified Presence of Address on the Userpage");
		
		//Validating presence of record in DB
		DBClass dbc=new DBClass();
		System.out.print("Retreiving the email to ensure that record has been added,email is:");
		dbc.tc012MyAccRecordValidation();
		Assert.assertEquals(dbc.myAccQuery,emailaddress);
		Reporter.log("New Record is added in DB");
		
	}

}
