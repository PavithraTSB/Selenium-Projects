package com.ibm.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.CategoriesPage;
import com.ibm.pages.ProductPage;
import com.ibm.pages.SystemPage;
import com.ibm.pages.SystemWeightClassPage;
import com.ibm.pages.UserPortalLoginPage;
import com.ibm.utilities.PropertiesFileHandler;

public class TC006 {

	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}
 
	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "UserPageValidation")
	public void testCase6() throws IOException, InterruptedException {

		            String url = data.get("url");
					String userName = data.get("uname");
					String password = data.get("pwd");
					
					
					driver.get(url);
					
					AdminPage admin = new AdminPage(driver, wait);
					admin.enterEmailAddress(userName);
					admin.enterPassword(password);
					admin.clickOnLogin();
					
					ProductPage pp =new ProductPage(driver,wait);
					pp.clickCatalog();
					
					CategoriesPage cp=new CategoriesPage(driver,wait);
					cp.categories();
					//cp.table();
					List<WebElement> rows = driver.findElements(By.xpath("//table[@id='dataTableExample2']/tbody/tr"));
					int noOfRows=rows.size();
					System.out.println(noOfRows);
					
					List<String> ls1=new ArrayList<>();
					for(int i=1;i<=noOfRows;i++)
					{
						WebElement categories = driver.findElement(By.xpath("//table[@id='dataTableExample2']/tbody/tr["+i+"]/td[2]"));
						
						String text = categories.getText();
						ls1.add(text);
						//System.out.println(text);
						
					}
					System.out.println(ls1);
					
					Thread.sleep(1000);
					
					String userUrl=data.get("userurl");
					driver.get(userUrl);
					UserPortalLoginPage uplp=new UserPortalLoginPage(driver,wait);
					
					uplp.shopByCategory();
					

					Thread.sleep(3000);
					
				
					String name="";
					
					List<String> c2=new ArrayList<>();
				
					for(int j=1;j<=10;j++)
					{
						
						
						WebElement wb=driver.findElement(By.xpath("//*[@id='categories-menu']/ul/li/div/div/ul/li["+j+"]/a"));
						
						name=wb.getText();
						//System.out.println(name);
						c2.add(name);
					
					}
					System.out.println(c2);
//					
					
					List<String> results= new ArrayList<>();
				

					for(int l=0;l<ls1.size();l++)
					{
						for(int k=0;k<c2.size();k++)
						{
							if(ls1.get(l).equals(c2.get(k)))
							{
								
							results.add(ls1.get(l));
							}
							
						
						}
					}
					System.out.println("List 1 matched values with list 2" + results);
					
					ls1.removeAll(c2);
					System.out.println("List 1 not matched values with list 2 : " + ls1);
					
}
}
