package com.ibm.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.EditProductPage;
import com.ibm.pages.ProductPage;
import com.ibm.pages.UserPortalLoginPage;
import com.ibm.utilities.PropertiesFileHandler;

public class TC008 {
	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "UserPageValidation")
	public void testCase8() throws IOException, InterruptedException {

		            String url = data.get("url");
					String userName = data.get("uname");
					String password = data.get("pwd");
					String search=data.get("searchProduct");
					
					driver.get(url);
					
					AdminPage admin = new AdminPage(driver, wait);
					admin.enterEmailAddress(userName);
					admin.enterPassword(password);
					admin.clickOnLogin();
					
					ProductPage pp =new ProductPage(driver,wait);
					pp.clickCatalog();
					pp.clickProducts();
					pp.sendkeysSearch(search);
					pp.actionTable();
					pp.clickEdit();
					
					EditProductPage epp =new EditProductPage(driver,wait);
					epp.clickData();
					epp.selectStatus();
					JavascriptExecutor jse = (JavascriptExecutor)driver;
					jse.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
					Thread.sleep(3000);
					epp.clickDataSave();
					
					String userUrl=data.get("userurl");
					driver.get(userUrl);
					
					UserPortalLoginPage uplp = new UserPortalLoginPage(driver,wait);
					uplp.clickSearchIcon();
					uplp.searchproduct(search);
					Thread.sleep(3000);
					uplp.clickOnSearchResults();
	}


}
