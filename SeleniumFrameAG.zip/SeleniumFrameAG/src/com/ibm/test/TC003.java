package com.ibm.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.MarketingPushNotificationPage;
import com.ibm.utilities.PropertiesFileHandler;

public class TC003 {
	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/*@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}*/

	@Test(testName = "NegativeValidationPushNotification")
	public void testCase3() throws IOException {

		
			
				try {
					String url = data.get("url");
					String userName = data.get("uname");
					String password = data.get("pwd");
					String notificationName=data.get("nName");
					String negativeValidation=data.get("pushnotificationPageTitle");
					driver.get(url);
					
					AdminPage admin = new AdminPage(driver, wait);
					admin.enterEmailAddress(userName);
					admin.enterPassword(password);
					admin.clickOnLogin();
					
					MarketingPushNotificationPage mpnp=new MarketingPushNotificationPage(driver, wait);
					mpnp.clickMarketing();
					mpnp.clickPushNotification();
					mpnp.clickAddButton();
					mpnp.sendNotificationName(notificationName);
					mpnp.clickSave();
					System.out.println(driver.getTitle());
					String pagetitle = mpnp.getPagetitleForNegativeValidation();
					
					
					Assert.assertTrue(pagetitle.equals(negativeValidation), "Assertion on negative validation");
					Reporter.log("Verified it is on the same page");
				} catch (Exception e) {
					System.out.println(e.getMessage());
					Reporter.log("Verified it is not on the same page");
					//screenshot
					//throw e;
					Assert.fail();
				}
				
}
}
