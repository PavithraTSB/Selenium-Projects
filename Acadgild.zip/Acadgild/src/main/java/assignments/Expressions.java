package assignments;

public class Expressions {

	public static void main(String[] args) {
		
		int a=20;
	    int b=10;
	    String j="Pavithra";
		
		//Performing the following operations and getting the output
		b = a-- - --a; //Post decrement -Pre decrement
		int c = a--;//Post decrement
		int d = a>>2;// Right shift operator
		int e = a&b; //AND operator
		j="Vishnu";
		
		System.out.println("b= "+b);
		System.out.println("c= "+c);
		System.out.println("d= "+d);
		System.out.println("e= "+e);

		
	}

}
