package assignments;

public class GetterSetter {

	//declaring the variables in private
	private String name;
	private long phno;
	private int rollno;
	
	public String getName()
	{
		return name;
		
	}
	public long getPhno()
	{
		return phno;
		
	}
	public int getRollno()
	{
		return rollno;
		
	}
	public void setName(String newName)
	{
		name=newName;
	}
	public void setPhno(long newPhno)
	{
		phno=newPhno;
	}
	public void setRollno(int newRollno)
	{
		rollno=newRollno;
	}
	public static void main(String[] args) {
		
		GetterSetter gs=new GetterSetter();
		gs.setName("Pavithra");
		gs.setPhno(937827282);
		gs.setRollno(4563);
		
		System.out.println("Name:"+ gs.getName()+ "\nPh no:"+ gs.getPhno()+ "\nRoll no:"+ gs.getRollno());
	}
}
