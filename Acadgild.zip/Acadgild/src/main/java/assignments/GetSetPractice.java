package assignments;

public class GetSetPractice {
	
	private String name;
	private int id;
	private int age;
	
	public String getName()
	{
		return name;
	}
	public int getId()
	{
		return id;
	}
	public int getAge()
	{
		return age;
		
	}
	
	public void setName(String newName)
	{
		name=newName;
	}
   public void setId(int newId)
   {
	   id=newId;
   }
   public void setAge(int newAge)
   {
	   age=newAge;
	   
   }
   
	public static void main(String[] args) {
		
		GetSetPractice gs=new GetSetPractice();
		gs.setAge(25);
		gs.setId(90182);
		gs.setName("Pavithra");
		System.out.println("Name:" +gs.getName() +"\nAge:" +gs.getAge() +"\nId:" +gs.getId());
	}

}
