package assignments;

public abstract class Figure {
	public double dim1;
	
	
	public abstract void findArea();
	
	public abstract void findPerimeter();
}
