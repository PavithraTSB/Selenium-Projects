package selenium;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PracticeWindowHandles {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.toolsqa.com/automation-practice-switch-windows/");
		driver.findElement(By.xpath("//button[@id='button1']")).click();
		driver.findElement(By.xpath("//button[text()='New Message Window']")).click();
		driver.findElement(By.xpath("//button[text()='New Browser Tab']")).click();
		
		Set<String>set = driver.getWindowHandles();
		List<String>ls=new ArrayList<>();
		ls.addAll(set);
		int size=ls.size();
		System.out.println("Number of windows :"+size);
		driver.switchTo().window(ls.get(1));
		driver.manage().window().maximize();
		String title = driver.getTitle();
		System.out.println(title);
		driver.switchTo().window(ls.get(0));
		driver.findElement(By.id("alert")).click();
		driver.switchTo().alert().accept();
		
		WebElement timingalert = driver.findElement(By.id("timingAlert"));
		timingalert.click();
		Thread.sleep(4000);
//		WebDriverWait wait=new WebDriverWait(driver,30);
//		wait.until(ExpectedConditions.elementToBeClickable(timingalert));
		driver.switchTo().alert().accept();

	}

}
