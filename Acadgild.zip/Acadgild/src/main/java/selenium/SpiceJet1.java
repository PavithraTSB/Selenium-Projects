package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SpiceJet1 {

	public static void main(String[] args) throws InterruptedException {

		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		//WebDriverWait wait = new WebDriverWait(driver,60);
		driver.manage().window().maximize();
		

		driver.get("http://www.spicejet.com");

		WebElement roundTripEle = driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1"));
		roundTripEle.click();


		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.xpath("//a[@value='MAA']")).click();

		driver.findElement(By.id("ctl00_mainContent_ddl_destinationStation1_CTXT")).click();
		driver.findElement(By.xpath("(//a[@value='BLR'])[2]")).click();

		driver.findElement(By.xpath("(//table[@class='ui-datepicker-calendar'])[2]/tbody/tr[2]/td[4]")).click();
		driver.findElement(By.xpath("(//table[@class='ui-datepicker-calendar'])[2]/tbody/tr[2]/td[6]")).click();
		driver.findElement(By.xpath("//div[@class='paxinfo']")).click();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//span[@id='hrefIncAdt']")).click();
		driver.findElement(By.xpath("//input[@value='Done']")).click();
		driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency")).click();
		driver.findElement(By.xpath("//select[@name='ctl00$mainContent$DropDownListCurrency']/option[3]")).click();
		driver.findElement(By.xpath("//input[@type='submit']")).click(); 

}

		} 


