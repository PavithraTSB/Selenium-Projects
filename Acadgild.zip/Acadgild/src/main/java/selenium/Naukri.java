package selenium;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Naukri {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://www.naukri.com");
		
		
		   List<WebElement> ls = driver.findElements(By.tagName("a"));
			int ls1 = ls.size();
			System.out.println(ls1);
		
			for (WebElement link : ls) {
				String attribute = link.getAttribute("href");
				String text = link.getText();
				
				System.out.println("Link is :"+link+"Text is :"+text);
				
			}
		driver.findElement(By.xpath("(//div[@class='mTxt'])[2]")).click();
		
		 Set<String> allWindows = driver.getWindowHandles();
	      List<String> list = new ArrayList<>();
	      list.addAll(allWindows);
	      driver.switchTo().window(list.get(1));
	      String title = driver.getTitle();
	      System.out.println(title);
	      
	      
	      driver.findElement(By.xpath("//span[@class='searchJob']")).sendKeys("Testing");
	      driver.findElement(By.xpath("//span[@class='blueBtn']")).click();
	      
	      driver.findElement(By.linkText("All Recruiters")).click();
	      
		
		
		
		
		
		

	}

}
