package selenium;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;



public class LearnWindows {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"./drivers/chromedriver.exe");		
		//Launch the Browser - chrome
		ChromeDriver driver = new ChromeDriver();
		//maximize the window
		driver.manage().window().maximize();
		//Load the URL
		driver.get("http://legacy.crystalcruises.com/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//System.out.println(driver.getTitle());
		driver.findElementByLinkText("GUEST CHECK-IN").click();
	    System.out.println(driver.getTitle());

	    Set<String>allWindows = driver.getWindowHandles();
	    List<String>noOfWindows=new ArrayList<>();
	    noOfWindows.addAll(allWindows);
	    driver.switchTo().window(noOfWindows.get(1));
	    driver.switchTo().window(noOfWindows.get(0));	    
	}

}
