package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AmazonActions {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in");
		WebElement category = driver.findElement(By.xpath("//span[text()='Category']"));
		
		Actions builder=new Actions(driver);
		Thread.sleep(2000);
		builder.moveToElement(category).perform();
		Thread.sleep(3000);
		WebElement womenFashion = driver.findElement(By.xpath("(//span[@class='nav-text'])[14]"));
		builder.click(womenFashion).perform();
		WebElement clothing = driver.findElement(By.xpath("(//span[text()='Clothing'])[2]"));
		builder.click(clothing).perform();
//		WebElement shopByEle= driver.findElement(By.xpath("//span[text()='Shop by']"));
//		WebElement echoAlexaEle=driver.findElement(By.xpath("(//span[text()='Echo & Alexa'])[1]"));
//		WebElement echoSpotEle= driver.findElement(By.xpath("//span[text()='Echo Spot']"));
		
		
//		Actions actions=new Actions(driver);
//		
//		actions.moveToElement(shopByEle).pause(2000).moveToElement(echoAlexaEle)
//			.pause(2000).moveToElement(echoSpotEle).pause(1000).click().build().perform();
//		
//		actions.moveToElement(shopByEle).build().perform();
//		Thread.sleep(2000);
//		actions.moveToElement(echoAlexaEle).build().perform();
//		Thread.sleep(2000);
//		actions.moveToElement(echoSpotEle).build().perform();	
//		Thread.sleep(2000);
//		
//		actions.moveToElement(shopByEle).build().perform();
//		Thread.sleep(2000);
//		
//		

	}

}
