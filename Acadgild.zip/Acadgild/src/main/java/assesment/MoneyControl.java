package assesment;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MoneyControl {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.moneycontrol.com/");
	
		driver.findElement(By.linkText("Stocks")).click();
		List<WebElement>rows = driver.findElements(By.xpath("//table[@class='pcq_tbl MT10']/tbody/tr"));
		int noOfRows=rows.size();
		System.out.println(noOfRows);
		driver.findElement(By.linkText("A")).click();
		
		for(int i=2; i<=noOfRows;i++)
		{
		WebElement linktext = driver.findElement(By.xpath("//table[@class='pcq_tbl MT10']/tbody/tr[("+i+")]/td"));
		String Companyname= linktext.getAttribute("href");
		System.out.println(Companyname);
		
		} 

	}

}
