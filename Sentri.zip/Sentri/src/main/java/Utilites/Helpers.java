package Utilites;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Helpers 
{
	
	public static WebDriver driver;
	
	
	
	public static void launch_Browser(String browser)
	{
		switch(browser.toLowerCase())
		{
		case "chrome":
			
			System.setProperty("webdriver.chrome.driver", ".//Webdrivers//chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			break;	
		}
	}
	
	
	public static void navigatetoURL(String URl)
	{
		driver.get(URl);
	}
	
	
	public static void send_Keys(WebElement ele,String value)
	{
		ele.sendKeys(value);
	}
	

}
