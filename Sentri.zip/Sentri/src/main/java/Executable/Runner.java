package Executable;

import Steps.Login;

public class Runner {

	public static void main(String[] args) {
		
		Login.login();

	}

}
