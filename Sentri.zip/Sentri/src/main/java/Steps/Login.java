package Steps;

import PageObjectModel.Login_POM;
import Utilites.Helpers;

public class Login 
{

	public static void login()
	{
		Helpers.launch_Browser("Chrome");
		Helpers.navigatetoURL("http://demo.sentrifugo.com/index.php/");
		Helpers.send_Keys(Login_POM.username_txtbox(), "jennifer@example.com");
		Helpers.send_Keys(Login_POM.pwd_txtbox(), "sentrifugo");
		Login_POM.btn_login().click();
	
	}
}
