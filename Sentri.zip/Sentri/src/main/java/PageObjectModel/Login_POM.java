package PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Utilites.Helpers;

public class Login_POM extends Helpers
{

	public static WebElement username_txtbox()
	{
		return driver.findElement(By.xpath("//*[@id='username']"));
	}
	
	public static WebElement pwd_txtbox()
	{
		return driver.findElement(By.xpath("//*[@id='password']"));
	}
	
	public static WebElement btn_login()
	{
		return driver.findElement(By.xpath("//*[@id='loginsubmit']"));
	}
}
