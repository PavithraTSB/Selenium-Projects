package workout;

public class Executable extends Common{

	
	public static void main(String[] args) {
		
		Common.browserlaunch();
		Common.launchurl("https://www.facebook.com/");
		Common.signup("Vasantha", "TS", "vghgh@gmail.com", "Sethuraman");
		
	}

}
