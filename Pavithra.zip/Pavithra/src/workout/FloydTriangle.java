package workout;

import java.util.Scanner;

public class FloydTriangle {

	public static void main(String[] args) {
		
		//int num=1;
		int size=5;
//	    Scanner scan = new Scanner(System.in);
//	 
//	    System.out.println("Enter the number of rows of Floyd's triangle to display");
//	    int n = scan.nextInt();
//	 
	    System.out.println("Floyd's triangle:");
	 
	    for (int i = 1; i <= size; i++)
	    {
	      for (int j = 1; j <= i; j++)
	      {
//	        System.out.println(num+" ");
//	        num++;
	    	  System.out.print("*");
	      }
	 
	      System.out.println(); // Moving to next row
	    }

	}

}
