package workout;

import java.util.*;  
import java.util.Collections;  

class Student{  
int rollno;  
String name;  
int age;  
Student(int rollno,String name,int age){  
this.rollno=rollno;  
this.name=name;  
this.age=age;  
}  

public String toString()
{
return "Roll no: " + rollno + "-Name: "+ name + "-Age: "+ age;
}
}  


class AgeComparator implements Comparator<Student>{  
public int compare(Student s1,Student s2){  
System.out.println("Age Compare");
if(s1.age==s2.age)  
return 0;  
else if(s1.age>s2.age)  
return 1;  
else  
return -1;  
}  
}  


class NameComparator implements Comparator<Student>{  
//overriden function
public int compare(Student s1,Student s2){  

System.out.println("Name Compare");
return s1.name.compareTo(s2.name);  
}  
} 


class ArrayListSort{ 
 
public static void main(String args[]){  
  
ArrayList<Student> al=new ArrayList<Student>();  

//al.sort();
//System.out.println("==========1============");

al.add(new Student(101,"Vijay",23));  
//System.out.println("==========2============");


al.add(new Student(106,"Ajay",27));  
al.add(new Student(105,"Jai",21));  

System.out.println("List made");


Collections.sort(al,new NameComparator()); //compare function gets called up behind the scene  
System.out.println("Sort function called");

//al.add(  new Student(109,"Seema",20));
//System.out.println("Sorting by Name..." + al);
 
for(Student st: al){  
System.out.println(st.rollno+" "+st.name+" "+st.age);  
}  
  
  
Collections.sort(al,new AgeComparator());    
//System.out.println("sorting by age..." + al);  
  
//Collections.sort(al,new AgeComparator());  
for(Student st: al){  
System.out.println(st.rollno+" "+st.name+" "+st.age);  

}    
}  
}  
  

