package workout;

public interface HDFCbank extends RBIBank {

	public void setHomeLoan();
}
