package workout;

import java.util.Scanner;

public class Groupnumbers {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the group name :");
		String gname = scan.next().toLowerCase();
		if(gname.contains("computer science")||gname.contains("computer")||gname.contains("science"))
		{
			System.out.println("It is a 1st group");
		}
		else if (gname.contains("Biology maths")||gname.contains("Maths")||gname.contains("Biology"))
		{
			System.out.println("It is a 2nd group");
		}

		else if(gname.contains("commerce"))
		{
			System.out.println("It is a 3rd group");
		}
		
		else
		{
			System.out.println("Invalid group name");
		}
	}

}