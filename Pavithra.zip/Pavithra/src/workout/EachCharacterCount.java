package workout;

import java.util.LinkedHashMap;
import java.util.Map;

public class EachCharacterCount {

	public static void main(String[] args) {
		
		String text="Pavithra";
		char ch[]=text.toCharArray();
		Map<Character,Integer>eachChar=new LinkedHashMap<>();
		for (char c : ch) {
			
			if(eachChar.containsKey(ch))
			{
				Integer value=eachChar.get(c);
				eachChar.put(c, value+1);
			}
			else
			{
				eachChar.put(c,1);
			}
		}

		System.out.println(eachChar);
	}

}
