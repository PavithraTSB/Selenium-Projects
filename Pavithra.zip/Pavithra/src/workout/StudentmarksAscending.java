package workout;

import java.util.Arrays;

public class StudentmarksAscending {

	public static void main(String[] args) {
		int marks [] = {100,95,84,88,91,56,78,48,39};
		int temp=0;
		for(int i=0;i<marks.length;i++)
		{
			for(int j=i+1;j<marks.length;j++)
			{
				if(marks[i]>marks[j])
				{
					temp=marks[i];
			        marks[i]=marks[j];
			        marks[j]=temp;
			        
				}
				
			}
			
		}
		for(int k=0;k<marks.length;k++)
		{
			System.out.println("Ascending order :"+marks[k]);
		}

		
		
	}

}
