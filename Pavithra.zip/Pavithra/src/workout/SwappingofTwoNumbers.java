package workout;

import java.util.Scanner;

public class SwappingofTwoNumbers {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the numbers");
		int num1= scan.nextInt();
		int num2=scan.nextInt();
		
		System.out.println("Numbers before swap"+"\nX="+num1+"\nY="+num2);
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("Numbers after swap"+"\nX="+num1+"\nY="+num2);

	}

}
