package workout;

public class Stringreverse {

	public static void main(String[] args) {
		String name ="Lovabaletime";
		String b="";
		
		
		for(int i=0;i<name.length();i++)
		{
			
			b=name.charAt(i)+b;
			
			System.out.println(b);
		}
		
		if(name.equals(b))
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not a Palindrome");
		}
	}

}
