package workout;

import java.util.Scanner;

public class Oddnum {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number :");
		int num = scan.nextInt();
		int sum=0;
		if(num%2!=0) {
			
			sum=sum+num;
		}
		
		System.out.println("Sum of odd numbers"+sum);
	}

}
