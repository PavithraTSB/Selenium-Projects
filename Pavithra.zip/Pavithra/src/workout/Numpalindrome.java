package workout;

public class Numpalindrome {

	public static void main(String[] args) {
		
		int num=545;
		int temp=0;
		temp=num;
		int b=0;
		//Reverse a number
		while(num!=0)
		{
			b=b*10;
			b=b+num%10;
			num=num/10;
		}
		System.out.println(b);
		//Palindrome or not
		if(b==temp)
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not a Palindrome");
		}
	}
	
	
	

}
