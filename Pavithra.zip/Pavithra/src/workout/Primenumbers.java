package workout;

public class Primenumbers {

	public static void main(String[] args) {
	
           int num = 7253;
    	   int i=2;
    	   boolean flag= false;
    	   
    	   
    	   while(i<=num/2)
    	   {
    		   if(num%i==0)
    		   {
    			   flag=true;
    			   break;
    		   }
    		   
    		   ++i;
    	   }
           
        if(!flag)
        {
        	System.out.println(num + "is Prime number");
        }
        else
        {
        	System.out.println(num + "is not a Prime number");
        }
           
        System.out.println(num%7253);
           
           
  
	}
}
