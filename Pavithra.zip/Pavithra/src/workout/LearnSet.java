package workout;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LearnSet {

	public static void main(String[] args) {
		
		List <Integer> ls = new ArrayList<>();
		ls.add(1234564);
		ls.add(5326863);
		ls.add(1234569);
		ls.add(1234567);
		ls.add(1234567);
		Set <Integer>set = new HashSet<>();
		set.addAll(ls);
		for(Integer value :set)
		{
			System.out.println(value);
		}
		if(ls==set)
		{
			System.out.println("false");
		}
		else
		{
			System.out.println("true");
		}
		
	}

}
