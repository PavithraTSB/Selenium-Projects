package workout;



public class FibonacciSeries {

	public static void main(String[] args) {
		int a=0,b=1,c;
		int num =10;
		for(int i=0;i<=num;i++)
		{
			
			c=a+b;
			a=b;
			b=c;
			System.out.println(c);
			
		}
		

	}

}
