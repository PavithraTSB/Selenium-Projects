package workout;

import java.util.Scanner;

public class EvennumArray {

	public static void main(String[] args) {
		int a[]=new int[10]; //declaring size of an array as 10
		int count=0;

		for(int i=1;i<=a.length;i++) //using for loop for iteration
		{
			if(i%2==0) // checking for the condition if the number is divisible by 2 then it is a even number
			{
				System.out.println(i);
				count++; 
			}
			
		}
		System.out.println("The total even numbers between 1 to 10 is :"+count);//getting total number of even number count

	}

}
