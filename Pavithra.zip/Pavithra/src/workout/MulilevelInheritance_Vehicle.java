package workout;

public class MulilevelInheritance_Vehicle {
	
	 public void vehicle()
	 {
		 System.out.println("Output of the Vehicle");
	 }

}
