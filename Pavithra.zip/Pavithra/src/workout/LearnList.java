package workout;

import java.util.ArrayList;
import java.util.List;

public class LearnList {

	public static void main(String[] args)
	{
		List <Integer> ls=new ArrayList<>();
		ls.add(10);
		ls.add(18);
		ls.add(15);
		ls.add(10);
		ls.add(15);
		int count =0;
		
		List <Integer> ls1=new ArrayList<>();
		
//		int size =ls.size();
//		System.out.println(ls.size());
//		for(Integer temp:ls)
//		{
//			System.out.println(temp);
//		}
		for(int i=0;i<ls.size();i++)
		{
			for(int j=i+1;j<ls.size();j++)
			{
				if (ls.get(i)==ls.get(j)) {
					count++;
//				System.out.println("The duplicate numbers are :"+ls.get(i));
//				
//				break;
				ls1.add(ls.get(i));}
				
				
				}
			
			
		}
		System.out.println(ls1);
		System.out.println("The duplicate number count is :"+count);
		
		}
}
