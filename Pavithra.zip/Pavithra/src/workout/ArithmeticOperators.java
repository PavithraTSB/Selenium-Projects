package workout;

import java.util.Scanner;

public class ArithmeticOperators {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the numbers");
		int num1=scan.nextInt();
		int num2=scan.nextInt();
		String action=scan.next();
		
	 switch(action)
	 {
	 case "add" :
		 System.out.println(num1+num2);
		 break;
		 
	 case "sub" :
		 System.out.println(num1-num2);
		 break;
		 
	 case "mul" :
		 System.out.println(num1*num2);
		 break;
		 
	 case "div" :
		 System.out.println(num1/num2);
		 break;
	 default :
		 System.out.println("Invalid");
		 break;
	 }
		 
	 
	}

}
