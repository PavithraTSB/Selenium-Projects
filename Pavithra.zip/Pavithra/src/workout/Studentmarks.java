package workout;

import java.util.Arrays;
import java.util.Scanner;

public class Studentmarks {

	public static void main(String[] args) {
//		int marks[]= {50,89,45,23,90,51,78,43,12};
//		//String str =Arrays.toString(marks);
//		System.out.println(Arrays.toString(marks));
//		int count=0;
//		for (int i=0;i<marks.length;i++)
//		{
//			if(marks[i]>=50)
//			count++;
//			
//		}
//
//		System.out.println(count);
//		
		int i = 5, j = 2;
		System.out.println( i % j );
	}

}
