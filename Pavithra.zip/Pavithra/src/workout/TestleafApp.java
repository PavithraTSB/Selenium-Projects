package workout;

import org.openqa.selenium.chrome.ChromeDriver;

public class TestleafApp {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	    driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Merge Leads").click();
		driver.findElementByXPath("//input[@id='partyIdTo']/following::img[@alt='Lookup']").click();
		driver.getWindowHandles();
		driver.get("http://leaftaps.com/crmsfa/control/LookupLeads?id=&parm0=LookupLeads");
		
		driver.findElementByXPath("//input[@name='firstName']/following::input[@name='lastName']").sendKeys("Vishnu");
		driver.findElementByXPath("//input[@name='lastName']/following::button[@class='x-btn-text']").click();

	}

}
