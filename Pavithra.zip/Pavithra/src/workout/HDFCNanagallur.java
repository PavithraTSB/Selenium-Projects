package workout;

public class HDFCNanagallur implements HDFCbank{

	

	@Override
	public void cardMinimumBalance() {
		
		System.out.println("Display cardMinimumBalance");
	}

	@Override
	public void setHomeLoan() {
		System.out.println("Set Home Loan %");
		
	}

}
