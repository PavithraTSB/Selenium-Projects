package workout;

public class Oddorevennum {

	public static void main(String[] args) {
		int num =73887;
		if(num%2==0)
		{
			System.out.println("The number is even");
		}
		else
		{
			System.out.println("The number is odd");
		}

	}

}
