package workout;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AlertFrameAuiIWindowhandles {

	public static void main(String[] args) throws InterruptedException {
		
		//Launch the browser
		System.setProperty("webdriver.chrome.driver", "./Drivers/Chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		
		//Login
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		
		//Buttons
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
				
		//Merge leads
	    driver.findElementByLinkText("Merge Leads").click();
		
		//window handling Merge Lead
	    driver.findElementByXPath("(//a[@class='buttonDangerous']/preceding::img[@alt='Lookup'])[1]").click();
		Set<String>window1=driver.getWindowHandles();
		List<String>window2=new ArrayList<>();
		window2.addAll(window1);
		driver.switchTo().window(window2.get(1));
		driver.manage().window().maximize();
		
		//From lead in new window
		driver.findElementByName("id").sendKeys("10437");
		driver.findElementByClassName("x-btn-text").click();
		Thread.sleep(2000);
		driver.findElementByClassName("linktext").click();
		
		//Switch to Primary window
		driver.switchTo().window(window2.get(0));
		
		
		//To Lead in new window using window handles
		driver.findElementByXPath("(//a[@class='buttonDangerous']/preceding::img[@alt=\"Lookup\"])[2]").click();
		Set<String>w1=driver.getWindowHandles();
		List<String>w2=new ArrayList<>();//No get() method in set so using list
		w2.addAll(w1);
		driver.switchTo().window(w2.get(1));
		driver.manage().window().maximize();
		driver.findElementByName("id").sendKeys("10438");
		driver.findElementByClassName("x-btn-text").click();
		Thread.sleep(2000);
		driver.findElementByClassName("linktext").click();
		
		//Again switching to primary window
		driver.switchTo().window(w2.get(0));
		
		//Merge
		driver.findElementByClassName("buttonDangerous").click();
		
		//Alert
		driver.switchTo().alert().accept();
		
		//Find Leads	
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByName("id").sendKeys("10438");
		driver.findElementByClassName("x-btn-text").click();

		//Closing the browser
		driver.quit();
	}

}
