package workout;

public class MainFunction {

	public static void main(String[] args) {
		
		Audi a= new Audi ();
		a.audi();
		a.car();
		a.vehicle();
	

}

}