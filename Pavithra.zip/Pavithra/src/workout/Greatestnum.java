package workout;

public class Greatestnum {

	public static void main(String[] args) {
		int num1=5;
		int num2=3;
		int num3=9;
		if(num1>num2 && num1>num3) {
			System.out.println("Greatest number is :"+num1);
		}
		else if(num2>num1 && num2>num3) {
			System.out.println("Greatest number is :"+num2);
		}
		else
		{
			System.out.println("Greatest number is :"+num3);
		}
       				

	}

}
