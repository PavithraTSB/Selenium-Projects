package workout;

import java.util.Set;
import java.util.TreeSet;

public class SetDupsRemove {

	public static void main(String[] args) {
		Set<String>set = new TreeSet<>();
		   set.add("Ajith");
	       set.add("Abhinavchand");
	       set.add("Pavithra");
	       set.add("Arjdund");
	       set.add("Prasanna");
	       set.add("Nishitha");
	       for(int i=0;i<set.size();)
	       {
	    	   if(set.contains("d"))
	    	   {
	    		   set.remove(i);
	    	   }
	    	   else
	    	   {
	    		   i++;
	    	   }
	       }
	     System.out.println(set);    
	}

}
