package workout;

public class RecursiveStringandNumber {

	public String reverseString(String str){
	if(str.isEmpty()){
        return str;
     } else {
        return reverseString(str.substring(1))+str.charAt(0);
     }
  }
  public static void main(String[] args) {
	  RecursiveStringandNumber obj = new RecursiveStringandNumber();
     String result = obj.reverseString("Tutorialspoint");
     System.out.println(result);
     
  }
} 
