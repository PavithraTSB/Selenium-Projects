package workout;

import org.openqa.selenium.chrome.ChromeDriver;

public class AlertFrame {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		driver.manage().window().maximize();
		//Frame
		driver.switchTo().frame("iframeResult");
		//button inside the frame
		driver.findElementByXPath("//button[text()='Try it']").click();
		//Alert
		driver.switchTo().alert().sendKeys("Pavithra");
		String text = driver.switchTo().alert().getText();
		System.out.println(text);
		driver.switchTo().alert().accept();
		//Contains
	    if(text.contains("Hello"));
	    {
	    	System.out.println("Yes");
	    }
	    
		
		
	}

	
}
