package workout;

public class Practice {

	public static void main(String[] args) {
		int a=5;
		float x=a/2;
		System.out.println(x);

	}

}
