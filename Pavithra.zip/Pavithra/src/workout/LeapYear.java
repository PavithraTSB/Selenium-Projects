package workout;

import java.util.Scanner;

public class LeapYear {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Year");
		int n =scan.nextInt();
		boolean yr=false;
		
		if(n%4==0) 
		{
			if(n%100==0)
			{
				if(n%400==0)
				{
			
			yr=true;
		}
		else
		{
			yr=false;
		}
		
	}

}
		if(yr)
			System.out.println("leap yr");
		else
			System.out.println("Not Leap yr");

}
}