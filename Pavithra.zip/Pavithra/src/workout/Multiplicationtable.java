package workout;

import java.util.Scanner;

public class Multiplicationtable {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = scan.nextInt();
		int mul=0;
		for(int i=1;i<=10;i++)
		{
			mul=i*num; 
			System.out.println(num+ "x"+i+"="+mul);
			
			
		}
		
	  // System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));
		
	}

}
