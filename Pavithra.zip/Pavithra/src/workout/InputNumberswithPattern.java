package workout;

import java.util.Scanner;

public class InputNumberswithPattern {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Numbers");
		int num1=scan.nextInt();
		int num2=scan.nextInt();
		
        if(num1%3==0 && num2%3==0)
        {
        	System.out.println("FIZZ");
        }
        else if(num1%5==0 && num2%5==0)
        {
        	System.out.println("BUZZ");
        }
        else if(num1%3==0 && num2%3==0 && num1%5==0 && num2%5==0)
        {
        	System.out.println("FIZZBUZZ");
        }
        else if(num1%3!=0 && num2%5!=0)
        {
        	
        	System.out.println(num1 + "and"+ num2);
        }
        	
        
	}

}
