package workout;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ListUpperLowercase {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in); 
//		System.out.println("Enter the String :");
//		String text =scan.next();
		List<String>ls = new ArrayList<>();
		ls.add("pavithra");
		
		
		for(int i=0;i<ls.size();i++)
		{
			char ch=ls.get(i).charAt(i);
//			
		    	//if(i%2==0)
		    	//{
		    		System.out.println(Character.toUpperCase(ch));
		    	//}
		    	//else
//		    	{
//		    		System.out.println(Character.toLowerCase(ch));
//		    		
//		    	}
		    }
			System.out.print(" ");
			//break;
			
			
//		}
		
		
		
	}

	}
	
