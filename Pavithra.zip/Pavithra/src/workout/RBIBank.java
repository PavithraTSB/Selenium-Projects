package workout;

public interface RBIBank {
	
	void cardMinimumBalance();
}
