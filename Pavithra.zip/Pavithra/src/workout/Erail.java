package workout;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Erail {

	

	public static void main(String[] args) throws IOException {
		
		//Connection with Chrome
		System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		//Maximize window
	    driver.manage().window().maximize();
	    
	    //Launch url
		driver.get("https://erail.in/");
		
		//Wait
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		//clear existing values
		driver.findElementById("txtStationFrom").clear();
		
		//Send keys using and using tab button to move to next field
		driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("MYS",Keys.TAB);
		
		//Checkbox
		WebElement check= driver.findElementById("chkSelectDateOnly");
		if(check.isSelected())
		{
			check.click();
		}
		
		//Table
		WebElement table=driver.findElementByXPath("//table[@class='DataTable TrainList']");
		List<WebElement>rows=table.findElements(By.tagName("tr"));
		System.out.println(rows.size());
		for (int i = 0; i <rows.size(); i++) {
			WebElement eachRow = rows.get(i);
		
			List<WebElement>allcell = eachRow.findElements(By.tagName("td"));
			System.out.println(allcell.get(1).getText());
			
			//To take Screenshot
			File src = driver.getScreenshotAs(OutputType.FILE);
			File desc = new File("./snaps/img.png");
			FileUtils.copyFile(src, desc);
			
				
		}
		
		
		
		
	}

}
