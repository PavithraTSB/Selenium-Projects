package workout;

public class Test {

	
		static int i = 0;
		public static void main(String args[]){
		Test t = new Test();
		t.print();
		}

		public void print(){
		System.out.println(this.i);
		}
	}


