package workout;

public class Numreverse {

	public static void main(String[] args) {


		int number=1234556,temp;
		
		temp=number;
		int b=0;
		
		while(number!=0)
		{
			b= b * 10;
			
			b= b + number%10;
			
			number=number/10;
			
		}
		System.out.println(b);
		
		

	if(temp==b)
	{
		System.out.println("The number is Palindrome");
	}
	else
	{
		System.out.println("Not a Palindrome");
	}

}
}