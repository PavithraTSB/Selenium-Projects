package workout;

public class Myphone {

	public static void main(String[] args) {
		
		//To call classname
		 
		Mobilephone mob=new Mobilephone();
//		 mob.toCall();
//		 mob.toMsg();
//		 mob.toBrowse();
		 //mob.doorno=50;
		 
		 
		System.out.println(mob.doorno);
		 System.out.println(mob.toMsg());
		
	}

}
