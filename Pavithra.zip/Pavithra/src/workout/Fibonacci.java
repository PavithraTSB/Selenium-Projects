package workout;

public class Fibonacci {

	public static void main(String[] args) {
		
		int a=1,b=1,c;
		int n=10;
		for(int i=1;i<n;++i)
		{
			
			c=a+b;
			a=b;
			b=c;
			System.out.println(a);
		}
	
		
	}

}
