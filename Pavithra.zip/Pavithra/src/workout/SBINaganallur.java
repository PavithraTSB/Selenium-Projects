package workout;

public class SBINaganallur implements SBIbank{

	

	@Override
	public void cardMinimumBalance() {
		System.out.println("Display cardMinimumBalance ");
		
	}

	@Override
	public void discountForSalaryAccount() {
		System.out.println("Display discountForSalaryAccount");
		
	}

	@Override
	public int setpercentageforpersonalloan() {
		System.out.println("Set the percentageforpersonalloan");
		return 0;
	}

}
