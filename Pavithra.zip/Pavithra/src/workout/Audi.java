package workout;

public class Audi extends Car {

	public void audi()
	{
		System.out.println("Output of the Audi");
	}
	
	
}
