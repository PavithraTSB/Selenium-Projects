package workout;

import java.util.Arrays;

public class Firstnthirdlargest {

	public static void main(String[] args) {
	
    int number []= {10,40,30,67,98,43,56};
    int size = number.length;
    int temp;
//    Arrays.sort(number);
//    System.out.println("The numbers are :"+ Arrays.toString(number));
//    System.out.println("The first largest number is :"+ number[size-1]);
//    System.out.println("The third largest number is :"+ number[size-3]);

    for(int i=0;i<size;i++)
    {
    	for (int j=i+1;j<size;j++)
    	{
    		if(number[i]>number[j])
    		{
    			temp =number[i];
    			number[i]=number[j];
    			number[j]=temp;
    			System.out.println(temp);
    		}
    	}
    }
    System.out.println("The third largest number is :"+number[size-3]);
    System.out.println("The first largest number is :"+number[size-1]);
	}

}
