package workout;

import java.util.Scanner;

public class Arrayoddeven {

	public static void main(String[] args) {
    String [] name = {"Hi","welcome", "to", "the", "world"};
    
    String a ="";
    
    
    for(int i=0;i<name.length;i++)
    {
    	a=a+name[i];
    }
    int len = name.length;
    System.out.println(len);
    int leng=a.length();
    System.out.println(a);
    System.out.println(leng);
    
    
    if(leng%2==0)//even
    {
    	
    	System.out.println(a.charAt(0) + " "+ a.charAt(1));
    }
    else//odd
    {
    	System.out.println(a.charAt(leng-2));
    }
	}

}
