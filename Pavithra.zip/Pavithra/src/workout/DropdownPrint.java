package workout;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownPrint {

	public static void main(String[] args) {
	
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		//Launch url
		driver.get("https://www.facebook.com/");
		//Year Dropdown
		WebElement month=driver.findElementById("month");
		Select mon = new Select(month);
		mon.selectByVisibleText("Mar");
		
		WebElement day=driver.findElementById("day");
		Select day1=new Select(day);
		day1.selectByIndex(27);
		
		WebElement year=driver.findElementById("year");
		Select yr1=new Select(year);
		yr1.selectByValue("1992");
		
		
		List<WebElement>yr=driver.findElementsById("year");
		
		for(int i=0;i<yr.size();i++)
		{
				
			String print=yr.get(i).getText();
			System.out.println(print);
			
		}
		

	}

}
