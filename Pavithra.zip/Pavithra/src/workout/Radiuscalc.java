package workout;

public class Radiuscalc {

	public static void main(String[] args) {
		double r=7.5;
		double p = 2*Math.PI*r;
		double a=Math.PI*r*r;
		System.out.println(p);
		System.out.println(a);
		
		

	}

}
