package workout;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Common {
  
    public static WebDriver driver;
    
	public static void browserlaunch()
	{
		System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	
	public static void launchurl(String url)
	{
		driver.get(url);
	}
    public static void signup(String fname,String lname,String mob,String pwd)
    {
    	driver.findElement(By.xpath("//*[@name='firstname']")).sendKeys(fname);
    	driver.findElement(By.xpath("//*[@name='lastname']")).sendKeys(lname);
    	driver.findElement(By.xpath("//*[@name='reg_email__']")).sendKeys(mob);
    	driver.findElement(By.xpath("//*[@name='reg_passwd__']")).sendKeys(pwd);
    	
        
   
    }
}
