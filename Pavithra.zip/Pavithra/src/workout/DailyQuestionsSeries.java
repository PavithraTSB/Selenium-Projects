package workout;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DailyQuestionsSeries {

	public static void main(String[] args) {
		
		
	   //Last But one from dropdown
		
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/Dropdown.html");
		//checkbox
		WebElement Listbox=driver.findElementByXPath("(//select[@class='dropdown']/following::select)[1]");
		Select Lb=new Select(Listbox);
		//collecting all the options
		List<WebElement>options= Lb.getOptions();
		//finding the size of the options
		int size=options.size();
		//choosing last but one option from the dropdown
		Lb.selectByIndex(size-2);
		
		

	}

}
