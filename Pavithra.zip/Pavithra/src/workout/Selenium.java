package workout;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class Selenium {
	static int i=0;

	public static void main(String[] args) throws InterruptedException {
		
		//Connections with Chrome driver
		System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Maximize the window
	    driver.manage().window().maximize();
	    //Launch url
		driver.get("http://leaftaps.com/opentaps");
		//Login
		
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		//Buttons 
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();;
		driver.findElementByLinkText("Create Lead").click();
		//To fill the form
//		driver.findElementByXPath("//input[@id='createLeadForm_companyName']").sendKeys("CTS");
//		driver.findElementByXPath("//input[@id='createLeadForm_firstName']").sendKeys("Vrishank");
//		driver.findElementByXPath("//input[@id='createLeadForm_lastName']").sendKeys("Abhinav");
		//Dropdown
		WebElement source =driver.findElementByXPath("//*[@id='createLeadForm_dataSourceId']");

		Select se =new Select(source);
		
		
	
		List<WebElement>se1=driver.findElementsByXPath("//*[@id='createLeadForm_dataSourceId']");
		for (WebElement eachoption : se1) {
			
			System.out.println(eachoption.getText());
			if(eachoption.getText().startsWith("C"))
			{
				i++;
				System.out.println("Starts with C \n"+eachoption.getText());
				
			}
			
		}
		
		
		
		

		
//		WebElement marketing= driver.findElementByXPath("//*[@id='createLeadForm_marketingCampaignId']");
//		Select mc=new Select(marketing);
//		mc.selectByValue("CATRQ_AUTOMOBILE");
//		//To fill the form
//		driver.findElementByXPath("//input[@id='createLeadForm_firstNameLocal']").sendKeys("Pavi");
//		driver.findElementByXPath("//input[@id='createLeadForm_lastNameLocal']").sendKeys("tsb");
//		driver.findElementByXPath("//input[@id='createLeadForm_personalTitle']").sendKeys("Mrs");
//		driver.findElementByXPath("//input[@id='createLeadForm_generalProfTitle']").sendKeys("Selenium");
//		driver.findElementByXPath("//input[@id='createLeadForm_departmentName']").sendKeys("Testing");
//		
//		WebElement cur=driver.findElementByXPath("//*[@id='createLeadForm_currencyUomId']");
//		Select pc=new Select(cur);
//		pc.selectByIndex(4);
//		
//		WebElement owner = driver.findElementById("createLeadForm_ownershipEnumId");
//     	Select own= new Select(owner);
//     	own.selectByVisibleText("LLC/LLP");
//     	
//     	driver.findElementByXPath("//*[@id='createLeadForm_description']").sendKeys("All is Well");
//     	driver.findElementByXPath("//input[@id='createLeadForm_primaryPhoneCountryCode']").clear();
//     	driver.findElementByXPath("//input[@id='createLeadForm_primaryPhoneCountryCode']").sendKeys("+91");
//     	driver.findElementByXPath("//input[@id='createLeadForm_primaryEmail']").sendKeys("abc@gmail.com");
//		
//     	WebElement state = driver.findElementByXPath("//*[@id='createLeadForm_generalStateProvinceGeoId']");
//     	Select sp = new Select(state);
//     	sp.selectByVisibleText("Arizona");
//     	
//     	driver.findElementByXPath("//*[@name='submitButton']").click();
//     	
//     	driver.findElementByLinkText("Find Leads").click();
//     	driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("Pavithra");
//     	driver.findElementByXPath("(//td[@class='x-panel-btn-td'])[6]").click();
//     	Thread.sleep(3000);
//     	driver.findElementByXPath("(//a[@class='linktext'])[4]").click();
//     	driver.findElementByXPath("//a[@class='subMenuButton'][3]").click();
//     	
//     	driver.findElementByName("lastName").sendKeys("Vishnu");
//     	driver.findElementByName("submitButton").click();
     	
     	
//     	WebElement table = driver.findElementByXPath("//div[@class='x-panel-body xedit-grid']");
//     	List<WebElement>rows=table.findElements(By.tagName("tr"));
//     	System.out.println(rows.get(1).getText());
//     	List<WebElement>columns=table.findElements(By.tagName("td"));
//     	System.out.println(columns.get(1).getText());
     	
     	
		
//		driver.findElementById("createLeadForm_companyName").sendKeys("IBM");
//		driver.findElementById("createLeadForm_firstName").sendKeys("Pavithra");
//		driver.findElementById("createLeadForm_lastName").sendKeys("vishnu");
//		//For dropdowns
//		WebElement source = driver.findElementById("createLeadForm_dataSourceId");
//		Select se= new Select(source);
//		se.selectByVisibleText("Employee");
//		
//		WebElement sem = driver.findElementById("createLeadForm_currencyUomId");
//		Select cur = new Select(sem);
//		cur.selectByValue("DZD");
//		
//		WebElement owner = driver.findElementById("createLeadForm_ownershipEnumId");
//		Select own= new Select(owner);
//		List<WebElement> own1 =se.getOptions();
//		for (WebElement eachoption : own1) {
//			System.out.println(eachoption.getText());
//			
//		}
//		
//		driver.findElementByName("submitButton").click();
//		driver.findElementByLinkText("Find Leads").click();
//		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys("Pavithra");
//		driver.findElementByXPath("(//td[@class='x-panel-btn-td'])[6]").click();
//		
	
		
		}

}
