package workout;

import java.util.Scanner;

public class Stringcheck {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String");
		String text = scan.next();
		int count=0;
		String lowerCase = text.toLowerCase();
		char [] ch = lowerCase.toCharArray();
		
		for (int i=0;i<ch.length;i++)
		{
			if(ch[i]=='a')
				count++;
		}
		
		System.out.println(count);
	}

}
