package workout;

public class SumofPrimenums {

	public static void main(String[] args) {
		int n =30;
		for(int i=1;i<=n;i++)
		{
			int j;
			for(j=2;j<i;j++)
			{
				int a=i%j;
				if(a==0)
				{
					break;
				}
			}
				if(i==j)
				{
					System.out.println("The Prime numbers are :"+i);
				}
			}
		}

	}


