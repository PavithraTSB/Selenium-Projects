package workout;

import java.util.Scanner;

public class ArithmeticOperations {

	public static void main(String[] args) {
		
//		int num1=125;
//		int num2=24;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the numbers");
		int num1=scan.nextInt();
		int num2=scan.nextInt();
		int add = num1+num2;
		int sub = num1-num2;
		int mul=num1*num2;
		int div=num1/num2;
		int mod=num1%num2;
		System.out.println(add);
		System.out.println(sub);
		System.out.println(mul);
		System.out.println(div);
		System.out.println(mod);
		
		
		}

}
