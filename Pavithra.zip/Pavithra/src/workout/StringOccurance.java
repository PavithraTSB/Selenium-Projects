package workout;

public class StringOccurance {

	public static void main(String[] args) {
		String data="TestLeaf";
		int count=0;
		
		char ch[]=data.toCharArray();
		
		for(int i=0;i<ch.length;i++)
		{
			
		}
	}

}
