package workout;

public interface SBIbank extends RBIBank {

	public void discountForSalaryAccount();
	int setpercentageforpersonalloan();

	
	
	
}
