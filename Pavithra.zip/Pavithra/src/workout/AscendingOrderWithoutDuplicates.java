package workout;


import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class AscendingOrderWithoutDuplicates {

	public static void main(String[] args) {
		int temp=0;
    List<Integer>ls=new ArrayList<>();
    ls.add(18);
    ls.add(12);
    ls.add(12);
    ls.add(18);
    ls.add(19);
    ls.add(100); 
    ls.add(2);
    Set<Integer>set=new TreeSet<>();
    set.addAll(ls);
    System.out.println(set);
	}

}
