package workout;

public class MinMaxArray {

	public static void main(String[] args) {
		
		int a[]={11,13,3,7,18,8,9};
		int size=a.length;
		int temp=0;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(a[i]>=a[j])
				{ 
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		for(int k=0;k<size;k++)
		{
			
			System.out.println(a[k]);
		}
		System.out.println("Min number in the array: " +a[0]);
		System.out.println("Max num in the array: " +a[size-1] );
	}

}
