package workout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CollectionsSort {

	public static void main(String[] args) {
	List<Integer>ls=new ArrayList<>();
	ls.add(10);
	ls.add(78);
	ls.add(18);
	ls.add(43);
	ls.add(10);
	Set<Integer>set1=new TreeSet<>();
	set1.addAll(ls);
	//Collections.sort(ls);//Ascending
	//Collections.sort(set1, Collections.reverseOrder());//Descending
	System.out.println(set1);	
	
		

	}

}
