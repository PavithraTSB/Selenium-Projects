package workout;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Ascendescend {

	public static void main(String[] args) {
		
		int arr []= {34,67,89,12,10,18,3};
		int temp=0;
		
//		Arrays.sort(arr);
//		System.out.println("Ascending order is :"+Arrays.toString(arr));
//		
//		Arrays.sort(arr, Collections.reverseOrder());
//		System.out.println("Descending order is :"+Arrays.toString(arr));
//		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
				
			{
				if(arr[i]>arr[j])
				{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				}
				
			}
		}
		for(int k=0;k<arr.length-1;k++)
	      {
	    	  System.out.println(arr[k]);
	      }
	}
      
}
