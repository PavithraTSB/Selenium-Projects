package workout;

import java.util.Scanner;

public class Strinmethds {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the names");
		String name = scan.nextLine();
		String [] names = {name};
	    //store the names in an array
	    for (int i = 0; i <10; i++){
	        names[i] = scan.nextLine();
	        }
	    

	}

}
