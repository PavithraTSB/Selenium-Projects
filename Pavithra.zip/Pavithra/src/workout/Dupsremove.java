package workout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class Dupsremove {

	public static void main(String[] args) {
		
       List<String>ls = new ArrayList<>();
       ls.add("Ajith");
       ls.add("Abhinavchand");
       ls.add("Pavithra");
       ls.add("Arjdund");
       ls.add("Prasanna");
       ls.add("Nishitha");
//       Set<String>set1 = new TreeSet<>();
//       set1.addAll(ls);
      for(int i=0;i<ls.size();)
      {
    	  if(ls.get(i).contains("d"))
    	  {
    		  ls.remove(ls.get(i));
    	  }
    	  else
    	  {
    		  i++;
    	  }
    	 
      }
       
       Collections.sort(ls);
       System.out.println(ls);

	}

}
