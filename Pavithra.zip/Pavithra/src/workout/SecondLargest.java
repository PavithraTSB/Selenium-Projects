package workout;

public class SecondLargest {

	public static void main(String[] args) {
		
		int a[]= {20,340,21,879,92,21,474,83647,-200};
		int size = a.length;
		int temp=0;
		for(int i=0;i<=size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
				
			}
			System.out.println(temp);
		}
		System.out.println("Second largest number = "+a[size-2]);

	}

}
