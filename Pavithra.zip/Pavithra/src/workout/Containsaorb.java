package workout;

public class Containsaorb {

	public static void main(String[] args) {
	
		String arr[] = {"Vishnu","Pavithra","Bhuvana","Murali","Prasanna","Abi","Lakshmi","Punitha","Revathy"};
		
		for(int i=0;i<arr.length;i++)
		{
		
			 
			if(arr[i].contains("B")|| arr[i].startsWith("A"))
			{
				System.out.println(arr[i]);
			}
		}

	}

}
