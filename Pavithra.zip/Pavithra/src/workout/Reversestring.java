package workout;

import java.util.Scanner;

public class Reversestring {

	public static void main(String[] args) {
		
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter the String");
		String name=scan.next();
		String b="";
		
		for(int i=0;i<name.length();i++)
		{
			b=name.charAt(i) + b;
			
		}
		System.out.println(b);
		
		if(name.equals(b))
		{
			System.out.println("Palindrome");
		}
		
		else
		{
			System.out.println("Not a palindrome");
		}
	
	}
}
