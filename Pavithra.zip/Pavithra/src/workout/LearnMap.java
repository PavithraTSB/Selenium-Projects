package workout;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LearnMap {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the Word");
		String text = scan.next();
	   char [] ch = text.toCharArray();
	   Map<Character,Integer>emp =new HashMap<>();
	  
	   for (char c : ch) {
		
	    if(emp.containsKey(c))
		   {
			   //Integer value = emp.get(c);
			   emp.put(c, emp.get(c)+1);
		   }
		   else
		   {
			   emp.put(c, 1);
		   }
	   }
	  
	   
   System.out.println(emp);
  
  
	}

}

