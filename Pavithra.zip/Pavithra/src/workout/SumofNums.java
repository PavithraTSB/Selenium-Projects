package workout;

public class SumofNums {

	public static void main(String[] args) {
		
		int a [] = {25,26,9,18,3,12};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
			
		}
		System.out.println("Sum of numbers in a array :"+sum);
	}

}
