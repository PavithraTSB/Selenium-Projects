package workout;

public class ReverseStringPractice {

	public static void main(String[] args) {
		
		String val="I am doing good";
		String b="";
//		for(int i=0;i<val.length();i++)
//		{
//			b=val.charAt(i)+b;
//			
//		}
//		System.out.println(b);
//		if(val.equalsIgnoreCase(b))
//		{
//			System.out.println("String is a Palidrome");
//		}
//		else
//		{
//			System.out.println("Not a Palindrome");
//		}
		
		
		//Another Way
		for(int i=val.length()-1;i>=0;i--)
		{
			b=b+val.charAt(i);
		}
			System.out.println(b);
       }

}


