package workout;

import java.util.ArrayList;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.gargoylesoftware.htmlunit.javascript.host.Set;


public class Irctc {

	public static void main(String[] args) throws  InterruptedException {
	
		 //To launch the Web browser
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		driver.findElementByLinkText("Contact Us").click();
		
		//Window Handling
		java.util.Set<String> windowHandles = driver.getWindowHandles();
		List<String>allwindows=new ArrayList<>();
		allwindows.addAll(windowHandles);
		
		//Switching to 2nd window & printing the title
		driver.switchTo().window(allwindows.get(1));
		System.out.println(driver.getTitle());
		
		//Closing all the opened window
		driver.quit();
		
		
	 
	}

}
