package workout;

import java.util.Scanner;

public class Switchstatements {

 public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
	    System.out.println("Enter the input : ");
	    int day =scan.nextInt();
		
		
		switch(day)
		{
		    
			case 1: System.out.println("Monday");
				break;
			case 2: 
				System.out.println("Friday");
				break;
			case 3:
				System.out.println("Wednesday");
				break;
			default:
				System.out.println("Invalid");
				break;
				
		}
	}

}
