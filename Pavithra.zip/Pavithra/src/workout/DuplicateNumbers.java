package workout;

public class DuplicateNumbers {

	public static void main(String[] args) {
		
		int num[]= {1,1,3,3,5,5,6,7,7,4};
		//int num[]= {1,2,1,2,1,3,2};
		//int temp=0;
		int count=0;
		for(int i=0;i<num.length;i++)
		{
			for(int j=i+1;j<num.length;j++)
			{
				if(num[i]==num[j])
				{
//					temp=num[i];
//					num[i]=num[j];
//					num[j]=temp;
					count++;
				}
				
			}
				
			if(count>=1)
				System.out.println(num[i]);
            count = 0;
			
		}
//		for(int k=0;k<num.length;k++)
//	      {
//	    	  System.out.println(num[k]);
//	      }
//		
	}

}
