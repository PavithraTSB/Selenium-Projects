package workout;

public class MainClass {

	public static void main(String[] args) {
	
		SBINaganallur sbi = new SBINaganallur();
		HDFCNanagallur hdfc =new HDFCNanagallur();
		sbi.cardMinimumBalance();
		sbi.discountForSalaryAccount();
		sbi.setpercentageforpersonalloan();
		hdfc.cardMinimumBalance();
		hdfc.setHomeLoan();
		
		
				

	}

}
