package workout;

public class Mobilephone {

    int doorno=26;
	String area;
	
   public void toCall()
   {
	   int number = 3527;
	   long num =63768293828l;
   }
   public String toMsg()
   {
	   String message ="Hi";
	   char msg = 'a';
	   return(message);
   }
   public String toBrowse()
   {
	   String browse1 ="www.google.com";
	   Boolean wifi = true;
	   return(browse1);
	   
   }
   }

