package workout;

public class Car extends MulilevelInheritance_Vehicle {
	
	public void car()
	{
		System.out.println("Ouput of the Car");
	}

}
