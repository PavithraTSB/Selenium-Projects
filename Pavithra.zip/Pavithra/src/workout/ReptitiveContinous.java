package workout;

public class ReptitiveContinous {

	public static void main(String[] args) {
		
		String a= "s,r,1,2,3,3,a,1,2,c,4,d,d,d,d,4,5,6,7,7,h,r"; 
		
		

	}

}
