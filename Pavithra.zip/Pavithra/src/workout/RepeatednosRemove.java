package workout;

public class RepeatednosRemove {

	public static void main(String[] args) {
		
		int a[]= {13,65,15,67,88,65,13,99,67,13,65,87,13};
		int temp=0;
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length-1;j++)
			{
				if(a[i]==a[j])
				{
//					temp=a[i];
//					a[i]=a[j];
//					a[j]=temp;
					
					System.out.println(a[i]);
					
					break;
					
					}
				
				}
			
			}
		}

}
