package workout;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class RemovedupsfromString {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the word");
		String word=scan.nextLine();
		String fWord= " ";
      
		char[] ch=word.toLowerCase().replace(" ", " ").toCharArray();
		//Set<Character>set =new LinkedHashSet<>();
		for(int i=0;i<ch.length;i++)
		{
			//set.add(ch[i]);
			if(fWord.indexOf(ch[i])==-1)
			{
				fWord=fWord+ch[i];
			}
			
		}
//		for (Character character : set) {
//			System.out.println(character);
//			
//		}
		System.out.println(fWord);
	
	  scan.close();
	}

}
