package workout;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkbox {

	public static void main(String[] args) {
		
		//Connection with chrome
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		//Launch url
		driver.get("http://testleaf.herokuapp.com/pages/checkbox.html");
		//To find the element of the checkbox
		WebElement check =driver.findElementByXPath("//*[@id='contentblock']/section/div[2]/input");
		if(check.isSelected())
		{
			check.click();
			//System.out.println("checkbox is selected");
		
		}
//		else
//		{
//			System.out.println("Checkbox is not selected");
//		}
//		
		

	}

}
