package workout;

import java.util.Scanner;

public class Password {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Please enter the password:");
		String pwd=sc.nextLine();
	    int pwdlength=pwd.length();
		int z=0,c=0,l=0,o=0;
		if(pwdlength>=10)
		{
			for(int i=0;i<pwd.length();i++)
			{
			char ch=pwd.charAt(i);
			if(Character.isUpperCase(ch))
			{
				c++;
			}
			
			else if(Character.isLetter(ch))
			{
				l++;
			}
			else if(Character.isDigit(ch))
					{
						z++;
					}
			 else
			 {
				o++;
			 }
			
			}
				if(z>=2 && l>=1 && c>=1 && o<=0)
				{
					System.out.println("Your passwod is valid ");
				}
				else
				{
					System.out.println("Password must contains 2 letters & 2 digits & 1 capital letter & don't enter special character");
					
				}}
			
		else
		{
			System.out.println("Password must contain 10 characters");
		}
		}
		}

	
	


