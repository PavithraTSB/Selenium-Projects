

public class Over_Load {
	public void Return() {
	// TODO Auto-generated method stub
		System.out.println("rt");
}	
	public void Return(int a) {
	// TODO Auto-generated method stub
		System.out.println(a);
}	

static class Inh extends Over_Load{
	public static void main(String args[]) {
		System.out.println();
		Over_Load inh1 = new Over_Load();
		Inh Inh2 = new Inh();
		inh1.Return();
		inh1.Return(7);
		Inh2.Return();
	}
	public void Return() {
	// TODO Auto-generated method stub
		System.out.println("INH_rt");
}	

}
}
