
public class Dup_Arr {

	public static void main(String[] args) {
	
		int [] arr = {1,10,20,60,30,20,40,100,90,80,10,30,30,10};
		
		int[] dup=new int[arr.length];
		
		System.out.println(arr.length);
		int k=0;
		
		for(int i=0;i<arr.length-1;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]==arr[j] && (i!= j))
				{
					//System.out.println("Duplicate element is :" + arr[j]);
					
					
					k=arr[j];
					
				}
				
			}
			System.out.println("Duplicate element is :" + k  ); 
		}
		  
		for(int q=0;q<arr.length;q++)
		{
			System.out.println(arr[q]);
		}
	}


	}


