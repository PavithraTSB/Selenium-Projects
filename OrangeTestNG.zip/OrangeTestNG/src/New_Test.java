
public class New_Test {
void check() {
	System.out.println("check");
	
}
public static void main(String args[])throws Exception {
	New_Test t = new New_Test();
	t.check();
}
}