
public class Test {
	
	public static void de(){
		
		int a=10;//Local variable
		System.out.println(a);
		
	}
	
	public int b=20;//instance variable
	static int c=30;//Static variable
	final int d=40;//final variable

	public static void main(String[] args) {
		
		Test tum =new Test();
		
		System.out.println(tum.b);
		System.out.println(tum.d);
		System.out.println(Test.c);
		tum.de();
		

	}

}
