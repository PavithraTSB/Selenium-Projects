import org.apache.poi.util.SystemOutLogger;

 /** --String methods--*/

public class strmethods {
	
	String s1 ="pavithra";
	String s2 =" Vishnu ";
	String s3 ="PAVITHRA";

	public static void main(String[] args) {
		
		String name = "Welcome to United States of America";
		strmethods org =new strmethods();
		System.out.println(org.s2.compareTo(org.s1));
		System.out.println(org.s1.equals(org.s3));
		System.out.println(org.s2.concat(org.s1));
		System.out.println(org.s1.charAt(5));
		System.out.println(org.s1.equalsIgnoreCase(org.s3));
		System.out.println(org.s1.toUpperCase());
		System.out.println(org.s3.toLowerCase());
		System.out.println(org.s2);
		System.out.println(org.s2.trim());
		System.out.println(name.substring(18,35));
		System.out.println(name.endsWith("America"));
		System.out.println(name.length());
		String[] arr=name.split(" ");
		int len =name.length();
		System.out.println(len);
		for(int i=0;i<=5;i++)
		{
			System.out.println(arr[i]);
		}
				
        System.out.println(name.lastIndexOf("ca"));
	}

}
