import java.io.InputStream;
import java.util.*;

public class Scanner1 {

	
	public static void main(String []args)  
		{ 
		 	Scanner1 scan = new Scanner1(System.in); //System.in is an inputstream 
		 	 
		 	System.out.println("Enter Your Name"); 
		 	String name = scan.nextLine(); 
		 	System.out.println("You are Name is "+name); 
		 	 
		 	System.out.println("Enter Your City"); 
		 	String city = scan.next(); 
		 	System.out.println("Your City is "+ city); 
		 	 
		 	System.out.println("Enter a Number");  	int num = scan.nextInt(); 
		 	System.out.println("Your Number is "+num); 
		 	 
		 	System.out.println("Enter a Mobile Number");  	long num2 = scan.nextLong(); 
		 	System.out.println("Your Mobile Number is "+num2); 
		 	 
		 	System.out.println("Enter a Value");  	double num3 = scan.nextDouble(); 
		 	System.out.println("Your Value is "+num3); 
		 	 
		 	System.out.println("Enter a Character");  	char a = scan.next().charAt(0);  	System.out.println("Your Char is "+a); 
		 	 
		 	System.out.println("Enter a Value");  	boolean val = scan.nextBoolean();  	System.out.println("Your Value is "+val); 
		 
		 	scan.close(); 
		} 

	}

}
