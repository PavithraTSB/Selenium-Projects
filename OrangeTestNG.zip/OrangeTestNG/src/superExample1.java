public class superExample1
{
static class Parentclass
{  
	String num="superValue"; 
	int s = 100;
} 
static class Middle
{
	
}
static class Innerclass extends Parentclass 
{  
	void printNumber() 
	{  
		int s = 101;
		System.out.println(super.num); 
		System.out.println(super.s); 
		System.out.println(s); 
		
	}  
	public static void main(String args[])  
	{   
		Innerclass obj= new Innerclass();   
		obj.printNumber();
	} 
  }
}