
public class Trythrow {

	public static void main(String[] args){
		try {
		int a[]=new int[2];
		a[0]=30/5;
		//a[2]=50;
		//a[3]=50;
		System.out.println(a[1]);
		}
		//catch(Exception e) {System.out.println("Exception1");}
		catch(ArrayIndexOutOfBoundsException e){System.out.println("Exception2");}
	    catch(ArithmeticException e) {System.out.println("common");}
	    //System.out.println("rest");

	}
}


