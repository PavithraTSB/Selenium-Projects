
public class Numethods {
	
	/** --Number Methods--*/
	
	public int add()
	{
		int a=10,b=20,c;
		return c=a+b;
	
		 
	}

	public static void main(String[] args) {
		
//		Integer a=100;
//		double b=45.62;
//		double c=87.56;
		
		Numethods num = new Numethods();
		System.out.println(num.add());
		
//		System.out.println(a.compareTo(90));
//		System.out.println(a.equals(100));
//		System.out.println(Math.abs(b));
//		System.out.println(Math.round(c));
//		System.out.println(Math.min(b,c));
//		System.out.println(Math.max(b,c));
//		System.out.println(Math.random());
//		String array[]= {"Pavi","Vishnu","Vrishank","Bhuvi"};
//		int len =array.length;
//		System.out.println(array.length);
//		System.out.println(array[2]);
//		for(int i=0;i<array.length;i++)
//		{
//			System.out.println(array[i]);
//		}
		}
	}


