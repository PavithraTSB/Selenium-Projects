package Javaprograms;

public class Primenumbers {

	public static void main(String[] args) {
		
		
		int prime=10;
		
		
		
		for(int i=1;i<=prime;i++)
		{
			int j;
			for( j=2;j<i;j++)
			{
				int output=i%j;
				
				if(output == 0)
				{
			break;
				}
			}
				 if(i == j)
				{
					System.out.println("Prime number:" + i);
				}
			
		}
System.out.println(2%2);
	}

}

