package Javaprograms;

import org.apache.poi.util.SystemOutLogger;

public class reversestring {

	public static void main(String[] args) {
	
		
		String name="Vishnu";
		
		String reverse="";
		
		for(int i=0;i<name.length();i++)
		{
			reverse=name.charAt(i)+reverse;
			System.out.println(reverse);
		}

	}

}
