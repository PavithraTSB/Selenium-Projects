package Javaprograms;

public class SortNormal {

	public static void main(String[] args) {
	
		int temp;
		
		int sort[]= {4,7,2,3,9,1};

		for(int i=0;i<sort.length;i++)
		{
			for(int j=i+1;j<sort.length;j++)
			{
				if(sort[i]>sort[j])
				{
					temp=sort[i];
					sort[i]=sort[j];
					sort[j]=temp;
				}
			}
		}
		
		for(int k=0;k<sort.length;k++)
		{
			System.out.println(sort[k]);
		}
	}

}
