package Javaprograms;

public class Reversepryamid {

	public static void main(String[] args) {
		int row=5;
		int j;
		for(int i=1;i<=row;i++)
		{
			for(j=1;j<=row-i;j++)
			{
				System.out.print(" ");
			}
			
			for(int k=1;k<=i;k++)
{
	System.out.print(j + " ");
}
			System.out.println("");
			
		}

	}

}
