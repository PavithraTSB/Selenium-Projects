package Javaprograms;

public class ThreeFive {

	static	String  T3="";
	static 	String T5="";
	static 	String T3and5="";
	static 	int i;
	
	public static void main(String[] args) {


		for(i=1;i<=20;i++)
		{
			
			if(i%3==0 && i%5==0)
			{
				T3and5="ThreeFive";
				System.out.println(T3+T5);
			}
		
			else if(i%3==0)
			{
				T3="Three";
				System.out.println(T3);
			
				
			}
			else if(i%5==0)
			{
				T5="Five";
				System.out.println(T5);
				
			}
			else
			{
				System.out.println(i);
			}
		
	
			
			
		}
		
	}

}
