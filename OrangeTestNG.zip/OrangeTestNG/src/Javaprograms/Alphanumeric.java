package Javaprograms;

public class Alphanumeric {

	public static void main(String[] args) {
		
		String word="a1dcv23sds$#"; 
		
		StringBuilder alphabets=new StringBuilder();
		StringBuilder numbers=new StringBuilder();
		StringBuilder sc=new StringBuilder();
		
		for(int i=0;i<word.length();i++)
		{
			char ch=word.charAt(i);
			
			if(Character.isAlphabetic(ch))
			{
				alphabets.append(ch);
			}
			else if(Character.isDigit(ch))
			{
				numbers.append(ch);
			}
			
			else
			{
				sc.append(ch);
			}
		}

		System.out.println(alphabets);
		System.out.println(numbers);
		System.out.println(sc);
	}

}
