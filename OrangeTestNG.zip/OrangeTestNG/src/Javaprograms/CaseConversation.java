package Javaprograms;

public class CaseConversation {

	public static void main(String[] args) {
		
				/*Input : THis is cRAZy
			    Output: thIS IS CrazY*/
				 char ch;
				String str="THis is cRAZy";
				StringBuffer sb=new StringBuffer();
				for(int i=0;i<str.length();i++)
				{
					ch=str.charAt(i);
					if(Character.isAlphabetic(ch))
					{
						//ch=str.charAt(i);		
						if(Character.isUpperCase(ch))
						{
							sb.append(Character.toLowerCase(ch));
						}
						else
						{
							sb.append(Character.toUpperCase(ch));	
						}
					}
					else
					{
						sb.append(ch);
					}	
				}
				System.out.println("Input: " + str);
			     System.out.println("Output: " +sb);			
						

			}

		



	}


