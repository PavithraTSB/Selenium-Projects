
public class spliting {
	
	/**Split -> Removing spaces*/

	public static void main(String[] args) {
		String name = "Mandadhadi Prasanth Vishnu";
		String[] arr = name.split(" ");
		int len =arr.length;
	    System.out.println(len);
	    for(int i=0;i<=2;i++)
	    {
	    	System.out.println(arr[i]);
	    }
		
	    System.out.println(name.lastIndexOf("n"));
	}

}
