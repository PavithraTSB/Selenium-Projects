package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test extends Utilites {

	public static void main(String[] args) {
		
//		System.setProperty("webdriver.chrome.driver", "C:\\Users\\PavithraTSB\\eclipse-workspace\\OrangeTestNG\\Drivers\\chromedriver.exe");
//		
//		WebDriver driver = new ChromeDriver();
		
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("http://opensource.demo.orangehrmlive.com");
		
		//driver.get("http://opensource.demo.orangehrmlive.com/");
		

	}

}
