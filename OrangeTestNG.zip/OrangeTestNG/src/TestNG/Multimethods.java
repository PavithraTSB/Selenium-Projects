package TestNG;

public class Multimethods extends Utilites {

	public static void facebook()
	{
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("https://www.facebook.com/login.php?login_attempt=1&lwv=110");
	}
	
	public static void orangehrm()
	{
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("https://www.orangehrm.com/");
	}
	

}
