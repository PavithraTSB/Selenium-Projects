package TestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Tablevalues extends Utilites {

	public static void main(String[] args) {
		
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("http://toolsqa.com/automation-practice-table/");
		
		List<WebElement> trow=driver.findElements(By.tagName("tr"));
		
		for(WebElement row:trow) {
			List<WebElement> tdata=driver.findElements(By.tagName("td"));
			for(WebElement data:tdata)
			{
				System.out.println(data.getText());
			}
		}

	}

}
