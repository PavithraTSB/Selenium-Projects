package TestNG;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class Screenshot extends Utilites{

	public static void main(String[] args) throws IOException {
		
		
		Utilites.launchBrowser("chrome");
		
		Utilites.launchURL("https://www.google.com/");
		
		TakesScreenshot sc=((TakesScreenshot)driver);
		
		File fs=sc.getScreenshotAs(OutputType.FILE);
		
		
		File loc=new File("C:\\Users\\PavithraTSB\\eclipse-workspace\\Screenshots\\sc.png");
		
		FileUtils.copyFile(fs,loc);

	}

}
