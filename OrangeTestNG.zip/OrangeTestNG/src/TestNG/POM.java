package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class POM extends Utilites {

	
	
	public static WebElement txtbox_username()
	{
		System.out.println("Driver:" + driver);
		return driver.findElement(By.xpath("//*[@id='txtUsername']"));
	}
	
	public static WebElement txtbox_password()
	{
		return driver.findElement(By.xpath("//*[@id='txtPassword']"));
	}
	
	public static WebElement btn_login()
	{
		return driver.findElement(By.xpath("//*[@id='btnLogin']"));
	}
	
	
	
	
}
