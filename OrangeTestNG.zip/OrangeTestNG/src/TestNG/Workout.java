package TestNG;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Set;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Workout {

	public static void main(String[] args) throws InvalidFormatException, IOException {
		
File f = new File("C:\\Users\\PavithraTSB\\eclipse-workspace\\OrangeTestNG\\Excel\\Orangehrm.xls");

XSSFWorkbook workbook = new XSSFWorkbook(f);


		}
}