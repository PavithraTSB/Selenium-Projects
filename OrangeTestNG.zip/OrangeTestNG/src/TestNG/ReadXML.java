package TestNG;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xmlbeans.impl.inst2xsd.util.Element;
import org.w3c.dom.Document;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadXML {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {


		File fp=new File("./src/TestNG/parallel.xml");
		
		DocumentBuilderFactory dfc=DocumentBuilderFactory.newInstance();
		DocumentBuilder dbuilder=dfc.newDocumentBuilder();
		Document doc=dbuilder.parse(fp);
		
		NodeList nl=doc.getChildNodes();
		
		Node n=nl.item(0);
		
		
		Element ele=(Element)n;
		
		System.out.println("" + ((Document) ele).getElementsByTagName("class").item(0).getTextContent());
		

	}

}
