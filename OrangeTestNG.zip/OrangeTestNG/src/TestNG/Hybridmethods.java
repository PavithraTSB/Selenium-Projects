package TestNG;

public class Hybridmethods  {

	 public static void valuepassing(String keywords,String data)
	  {
		  String value[]=data.split(";;");
		  switch(keywords.toLowerCase())
		  
		  {
		  case "launchbrowser":
			  Utilites.launchBrowser(value[0]);
			  break;
		 
		  case "launchurl":
			  Utilites.launchURL(value[0]);
			  break;  
			  
		  case "login":
			  Utilites.send_keys(POM.txtbox_username(), value[0]);
			  Utilites.send_keys(POM.txtbox_password(), value[1]);
			  Utilites.click(POM.btn_login());
			  break;  
			  
			  
		  }
	  }

}
