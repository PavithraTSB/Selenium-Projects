package TestNG;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Multiexecution extends Utilites {
	@Test
	public void facebook()
	{
//		Utilites.launchBrowser("chrome");
//		Utilites.launchURL("https://www.facebook.com/login.php?login_attempt=1&lwv=110");
//		driver.close();
	System.out.println("First");
	}
	
	@BeforeMethod
	public void first()
	{
		System.out.println("Before method");
	}
	
	@AfterMethod
	public void last()
	{
		System.out.println("last method");
	}
	@Test
	public  void orangehrm()
	{
//		Utilites.launchBrowser("chrome");
//		Utilites.launchURL("https://www.orangehrm.com/");
		
		System.out.println("second one");
	}
}
