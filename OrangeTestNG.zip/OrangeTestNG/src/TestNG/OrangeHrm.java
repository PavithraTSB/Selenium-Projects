package TestNG;

import org.testng.annotations.Test;

public class OrangeHrm {
  @Test
  public void login() {
	
	  Utilites.send_keys(POM.txtbox_username(), "");
	  Utilites.send_keys(POM.txtbox_password(), "");
	  Utilites.click(POM.btn_login());
	  
	  }
  
 
  
  
}
