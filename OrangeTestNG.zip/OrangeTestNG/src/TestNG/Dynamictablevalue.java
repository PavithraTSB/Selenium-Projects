package TestNG;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Dynamictablevalue extends Utilites {

	public static void main(String[] args) throws UnknownHostException {
		
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("http://toolsqa.com/automation-practice-table/");
		
		String name="Taipei 101";
		
		String result=null;
		
		List<WebElement> trow=driver.findElements(By.tagName("tr"));
		result=driver.findElement(By.xpath("//*[contains(text(),\"Taiwan\")]/parent::tr")).getText();
		
//		for(WebElement row:trow)
//		{
//			List<WebElement> columns=driver.findElements(By.tagName("th"));
//			
//			for(WebElement column:columns)
//			{
//
//				 result=driver.findElement(By.xpath("//*[contains(text(),\"Taiwan\")]/parent::tr")).getText();
//				
////				if(column.getText().contains(name))
////				{	
////					 
////				System.out.println(row.getText());
////				}
//			}
			System.out.println(result);
			//to get the ip address
		System.out.println(InetAddress.getLocalHost().getHostAddress());
		}

	}


