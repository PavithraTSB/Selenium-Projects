package TestNG;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class BrokenLinks extends Utilites {

	public static void main(String[] args) throws MalformedURLException, IOException {
	
		Utilites.launchBrowser("Chrome");
		String homepage="https://www.guru99.com/find-broken-links-selenium-webdriver.html";
		Utilites.launchURL(homepage);
		
		String url="";
		int responsecode;
		HttpURLConnection huc=null;
		
		
		
		List<WebElement> links=driver.findElements(By.tagName("a"));
		
		Iterator<WebElement> itr=links.iterator();
		
		while(itr.hasNext())
		{
			url=itr.next().getAttribute("href");
			
			System.out.println(url);
			
			if(url==null||url.isEmpty())
			{
				System.out.println("URL is Empty");
			}
			
			if(!url.startsWith(homepage))
			{
				System.out.println("URl is belongs to other domain");
			}
			
			huc=(HttpURLConnection)(new URL(url).openConnection());
			
			huc.setRequestMethod("HEAD");
			
			huc.connect();
			
			responsecode=huc.getResponseCode();
			
			if(responsecode>=200)
			{
				System.out.println("URL is broken link");
			}
		
			else
			{
				System.out.println("URL is valid link");
			}
		}
		

	}

}
