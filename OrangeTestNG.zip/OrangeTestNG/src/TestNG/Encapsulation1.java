package TestNG;

public class Encapsulation1 {

	public static void main(String[] args) {
		
		Encapsulation ep=new Encapsulation();
		
		ep.setEmpSSN(25);
		
		System.out.println(ep.setEmpSSN(25));
	}

}
