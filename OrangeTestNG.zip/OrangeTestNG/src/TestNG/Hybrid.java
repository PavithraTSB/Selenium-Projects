package TestNG;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;



public class Hybrid {

	public static void main(String[] args) throws BiffException, IOException {
		
		File f=new File("C:\\Users\\PavithraTSB\\eclipse-workspace\\OrangeTestNG\\Excel\\Orangehrm.xls");
		
		Workbook w=Workbook.getWorkbook(f);
		
		Sheet s=w.getSheet("Sheet1");
		
		int rowcount=s.getRows();
		int columncount=s.getColumns();
		
		for(int i=1;i<rowcount;i++)
		{
			for(int j=1;j<columncount;j++)
			{
				String keywords=s.getCell(j,i).getContents();
				
				String data=s.getCell(++j, i).getContents();
				
				System.out.println(keywords);
				System.out.println(data);
				Hybridmethods.valuepassing(keywords,data);
			}
		}
		

	}

}
