package TestNG;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class writeexcel {

	public static void main(String[] args) throws IOException {
		
		String data[]= {"vishnu","prasanth","pavithra"};
		
		//File file=new File("C:\\Users\\PavithraTSB\\eclipse-workspace\\Excel\\Write.xlsx");
		
		
		
		XSSFWorkbook wb=new XSSFWorkbook();
		
		XSSFSheet sh=wb.createSheet("sample");
		
		
		
		for(int i=0;i<data.length;i++)
		{
			XSSFRow row=sh.createRow(i);
			for(int j=i;j<=i;j++)
			{
			Cell cell=row.createCell(0);
			cell.setCellValue(data[i]);
		}}
		
		FileOutputStream outputstream=new FileOutputStream("C:\\Users\\PavithraTSB\\eclipse-workspace\\Excel\\Write\\" + "s.xlsx");
		
		wb.write(outputstream);
		
		outputstream.close();
		
		System.out.println("Successfully write the code");
		

	}

}
