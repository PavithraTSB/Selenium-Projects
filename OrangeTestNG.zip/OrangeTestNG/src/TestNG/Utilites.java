package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utilites {
	
	public static WebDriver driver;
	
	public static void launchBrowser(String browser)
	{
	
	switch(browser.toLowerCase())
	{
	
	case "chrome":
		
	System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
	
	driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	
	break;
	
	}
	
	}
	
	public static void launchURL(String url)
	{
		//System.out.println("URL :" + url);
		driver.get(url);
	}
	
	public static void send_keys(WebElement ele,String value)
	{
		ele.sendKeys(value);
	}
	
	public static void click(WebElement ele)
	{
		ele.click();
	}
	

	
	

}
