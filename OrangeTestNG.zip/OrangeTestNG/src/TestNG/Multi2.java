package TestNG;

import org.testng.annotations.Test;

public class Multi2 extends Utilites {
	@Test
	public  void orangehrm()
	{
		Utilites.launchBrowser("chrome");
		Utilites.launchURL("https://www.orangehrm.com/");
		driver.close();
	}
}
