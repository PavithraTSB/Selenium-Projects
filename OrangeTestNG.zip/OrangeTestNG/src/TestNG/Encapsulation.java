package TestNG;

public class Encapsulation {

	private int ssn;
    private String empName;
    private int empAge;

    //Getter and Setter methods
//    public int getEmpSSN(){
//        return ssn;
//    }

    public String getEmpName(){
        return empName;
    }

    public int getEmpAge(){
        return empAge;
    }

    public void setEmpAge(int newValue){
        empAge = newValue;
    }

    public void setEmpName(String newValue){
        empName = newValue;
    }

    public int setEmpSSN(int newValue){
        return ssn = newValue;
    }
}
