
public class Practice {
	
	public static void mega()
	{
		int a=10;
		System.out.println(a);
	}
	
	int b =40;
	static int c=30;
	private final int d=50;
	
	

	public static void main(String[] args) {
		String s="selenium";

		String s1=" SELENIUM ";

		String s2="Testing";
		String name=" Mega pavithra TSB";
	
		
//	   Practice CN =new Practice();
//	   System.out.println(CN.b);
//	   System.out.println(Practice.c);
//	   System.out.println(CN.d);
//	   CN.mega();
			   
	      /**Built in Methods*/
	   System.out.println(s.equals(s1));
	   System.out.println(s.compareTo(s2));
	   System.out.println(s1.concat(s2));
	   System.out.println(s2.charAt(3));
	   System.out.println(s.equalsIgnoreCase(s1));
	   System.out.println(s.toUpperCase());
	   System.out.println(s1.toLowerCase());
	   System.out.println(name);
	   System.out.println(name.trim());
	   System.out.println(name.substring(6,14));
	   System.out.println(name.endsWith("B"));
	   System.out.println(name.length());
	   String namee="Mega pavithra TSB";
	   
	  String[] arr=namee.split(" ");
	   
	   int len=arr.length;
	   
	   System.out.println(len);
	   
	 for(int i=0;i<=2;i++)
	   {
		 System.out.println(arr[i]);
	   }
	   
	//System.out.println(s.lastIndexOf("i"));
	}

}
