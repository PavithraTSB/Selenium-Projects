
public class Variable {
	
	static int Var1; //Static integer variable  	 
	String Var2; //Instance string variable  	
	public void staticVar() 
 	{ 
 	System.out.println("ob1 integer:"+Var1); 
 	System.out.println("ob2 STring:"+Var2); 
 	} 
 	public void nonStaticVar() 
 	{ 
 	System.out.println("ob2 integer:"+Var1); 
 	System.out.println("ob1 String:"+Var2); 
 	} 
 	   public static void main(String args[]) 
 	   { 
 	 	   Variable ob1 = new Variable(); 
 	 	   Variable ob2 = new Variable(); 
 	      Var1=88;  	    
 	      Var1=99;  	    
 	      ob1.Var2="I'm Object1";  	   
 	      ob2.Var2="I'm Object2";  	  
 	      ob1.staticVar();  	
 	      ob2.nonStaticVar(); 
 	   } 


}
