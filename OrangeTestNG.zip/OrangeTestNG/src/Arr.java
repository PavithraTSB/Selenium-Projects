
public class Arr {

	public static void main(String[] args) {
		
	    char[] test = {'A','B','C','D'};
		String[] testing= {"Pavi","Puni","Reva","Anki"};
		int[] phone= {10,20,30,40};
		Boolean[] boo = {true,false,true,false};
		int len = test.length;
		System.out.println(test.length);
		for(int i=0;i<len;i++)
		{
			System.out.println(test[i]);
		}
		
		int[] a= new int[3];
		a[0]=10;
		a[1]=20;
		a[2]=30;
		System.out.println(a[0]+a[1]);
		
		
		}
		
		}


